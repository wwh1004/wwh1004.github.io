using System.Reflection;

[assembly: AssemblyTitle("ControlFlow.Emulation")]
[assembly: AssemblyProduct("ControlFlow.Emulation")]
[assembly: AssemblyCopyright("Copyright © 2019 Wwh")]
[assembly: AssemblyVersion("1.0.0.2")]
[assembly: AssemblyFileVersion("1.0.0.2")]
