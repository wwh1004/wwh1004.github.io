using dnlib.DotNet.Emit;

namespace ControlFlow.Emulation {
	partial class Emulator {
		/// <summary />
		protected virtual bool Emulate_Beq(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Bge(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Bge_Un(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Bgt(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Bgt_Un(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Ble(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Ble_Un(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Blt(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Blt_Un(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Bne_Un(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Br(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Brfalse(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Brtrue(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Endfilter(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Endfinally(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Leave(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Ret(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Rethrow(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Switch(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Throw(Instruction instruction) {
			return false;
		}
	}
}
