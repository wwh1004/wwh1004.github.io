using dnlib.DotNet.Emit;

namespace ControlFlow.Emulation {
	partial class Emulator {
		/// <summary />
		protected virtual bool Emulate_Dup(Instruction instruction) {
			EvaluationStack.Push(EvaluationStack.Peek().Clone());
			// 也许有问题，如果是用户定义类型，有时间再看看如何处理
			// 我们要区分是一个值类型还是引用类型
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldarg(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldarga(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldc_I4(Instruction instruction) {
			EvaluationStack.Push(new Int32Value((int)instruction.Operand));
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldc_I8(Instruction instruction) {
			EvaluationStack.Push(new Int64Value((long)instruction.Operand));
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldc_R4(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Ldc_R8(Instruction instruction) {
			return false;
		}

		/// <summary />
		protected virtual bool Emulate_Ldelem(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldelem_I(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldelem_I1(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldelem_I2(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldelem_I4(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldelem_I8(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldelem_R4(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldelem_R8(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldelem_Ref(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldelem_U1(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldelem_U2(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldelem_U4(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldelema(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldfld(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldflda(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldftn(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldind_I(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldind_I1(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldind_I2(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldind_I4(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldind_I8(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldind_R4(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldind_R8(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldind_Ref(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldind_U1(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldind_U2(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldind_U4(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldlen(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldloc(Instruction instruction) {
			EvaluationStack.Push(Variables[(Local)instruction.Operand]);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldloca(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldnull(Instruction instruction) {
			EvaluationStack.Push(AnyValue.Null);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldobj(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldsfld(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldsflda(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldstr(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldtoken(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ldvirtftn(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Newarr(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Newobj(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Pop(Instruction instruction) {
			EvaluationStack.Pop();
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Starg(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stelem(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stelem_I(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stelem_I1(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stelem_I2(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stelem_I4(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stelem_I8(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stelem_R4(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stelem_R8(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stelem_Ref(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stfld(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stind_I(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stind_I1(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stind_I2(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stind_I4(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stind_I8(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stind_R4(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stind_R8(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stind_Ref(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stloc(Instruction instruction) {
			Variables[(Local)instruction.Operand] = EvaluationStack.Pop();
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stobj(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Stsfld(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}
	}
}
