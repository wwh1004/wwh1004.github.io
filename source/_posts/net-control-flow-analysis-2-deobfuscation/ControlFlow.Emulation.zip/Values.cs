namespace ControlFlow.Emulation {
	/// <summary>
	/// 值标志
	/// </summary>
	public enum ValueType {
		/// <summary>
		/// <see cref="object"/>
		/// </summary>
		Object,

		/// <summary>
		/// <see cref="bool"/>, <see cref="sbyte"/>, <see cref="byte"/>, <see cref="short"/>, <see cref="ushort"/>, <see cref="int"/>, <see cref="uint"/>
		/// 在CLR内最小单位是4字节
		/// </summary>
		Int32,

		/// <summary>
		/// <see cref="long"/>, <see cref="ulong"/>
		/// </summary>
		Int64,

		/// <summary>
		/// 空值，使用 <see cref="AnyValue"/> 表示
		/// </summary>
		Null,

		/// <summary>
		/// 未知值，使用任意继承自 <see cref="IValue"/> 的类型表示
		/// 比如使用 <see cref="Int32Value"/> 类表示，意思是类型为 <see cref="Int32Value"/>，但是值不确定
		/// </summary>
		Unknown,

		/// <summary>
		/// 数组，使用 <see cref="AnyValue"/> 表示。<see cref="AnyValue.Value"/> 将为 <see cref="IValue"/> 的数组
		/// </summary>
		Array,

		/// <summary>
		///用户定义类型
		/// </summary>
		User
	}

	/// <summary>
	/// 表示一个值
	/// </summary>
	public interface IValue {
		/// <summary>
		/// 标志
		/// </summary>
		ValueType Type { get; set; }

		/// <summary>
		/// 值类型返回 this 指针，引用类型深度克隆自身
		/// </summary>
		/// <returns></returns>
		IValue Clone();
	}

	/// <summary />
	public abstract class ValueBase : IValue {
		/// <summary />
		protected ValueType _type;

		/// <summary />
		public ValueType Type { get => _type; set => _type = value; }

		/// <summary />
		public abstract object Value { get; }

		/// <summary />
		internal ValueBase(ValueType type) {
			_type = type;
		}

		/// <summary />
		public override string ToString() {
			if (_type == ValueType.Unknown)
				return "<unknown>";
			else if (_type == ValueType.Null)
				return "<null>";
			else if (Value == null)
				return "null";
			else
				return Value.ToString();
		}

		/// <summary />
		public abstract IValue Clone();
	}

	/// <summary>
	/// 任意值
	/// </summary>
	public sealed class AnyValue : ValueBase {
		private static readonly AnyValue _null = new AnyValue(null, ValueType.Null);
		private static readonly AnyValue _unknown = new AnyValue(null, ValueType.Unknown);
		private object _value;

		/// <summary />
		public static AnyValue Null => _null;

		/// <summary />
		public static AnyValue Unknown => _unknown;

		/// <summary />
		public override object Value => _value;

		/// <summary>
		/// 值
		/// </summary>
		public object Object {
			get => _value;
			set => _value = value;
		}

		/// <summary>
		/// 构造器
		/// </summary>
		/// <param name="value"></param>
		/// <param name="type"></param>
		public AnyValue(object value, ValueType type) : base(type) {
			_value = value;
		}

		/// <summary />
		public override IValue Clone() {
			switch (_type) {
			case ValueType.Null:
				return _null;
			case ValueType.Unknown:
				return _unknown;
			default:
				return new AnyValue(_value, _type);
			}
		}
	}

	/// <summary>
	/// <see cref="bool"/>, <see cref="sbyte"/>, <see cref="byte"/>, <see cref="short"/>, <see cref="ushort"/>, <see cref="int"/>, <see cref="uint"/>
	/// </summary>
	public sealed class Int32Value : ValueBase {
		private static readonly Int32Value _unknown = new Int32Value(0) {
			_type = ValueType.Unknown
		};
		private uint _value;

		/// <summary />
		public static Int32Value Unknown => _unknown;

		/// <summary />
		public override object Value => _value;

		/// <summary>
		/// 值
		/// </summary>
		public int Int32 {
			get => (int)_value;
			set => _value = (uint)value;
		}

		/// <summary>
		/// 值
		/// </summary>
		public uint UInt32 {
			get => _value;
			set => _value = value;
		}

		/// <summary>
		/// 构造器
		/// </summary>
		/// <param name="value"></param>
		public Int32Value(int value) : base(ValueType.Int32) {
			_value = (uint)value;
		}

		/// <summary>
		/// 构造器
		/// </summary>
		/// <param name="value"></param>
		public Int32Value(uint value) : base(ValueType.Int32) {
			_value = value;
		}

		/// <summary />
		public override IValue Clone() {
			return this;
		}
	}

	/// <summary>
	/// <see cref="long"/>, <see cref="ulong"/>
	/// </summary>
	public sealed class Int64Value : ValueBase {
		private static readonly Int64Value _unknown = new Int64Value(0) {
			_type = ValueType.Unknown
		};
		private ulong _value;

		/// <summary />
		public static Int64Value Unknown => _unknown;

		/// <summary />
		public override object Value => _value;

		/// <summary>
		/// 值
		/// </summary>
		public long Int64 {
			get => (long)_value;
			set => _value = (ulong)value;
		}

		/// <summary>
		/// 值
		/// </summary>
		public ulong UInt64 {
			get => _value;
			set => _value = value;
		}

		/// <summary>
		/// 构造器
		/// </summary>
		/// <param name="value"></param>
		public Int64Value(long value) : base(ValueType.Int64) {
			_value = (ulong)value;
		}

		/// <summary>
		/// 构造器
		/// </summary>
		/// <param name="value"></param>
		public Int64Value(ulong value) : base(ValueType.Int64) {
			_value = value;
		}

		/// <summary />
		public override IValue Clone() {
			return this;
		}
	}

	/// <summary>
	/// 用户定义类型
	/// </summary>
	public abstract class UserValue : ValueBase {
		/// <summary />
		public UserValue(ValueType type) : base(type) {
		}
	}
}
