using dnlib.DotNet.Emit;

namespace ControlFlow.Emulation {
	partial class Emulator {
		/// <summary />
		protected virtual bool Emulate_Ceq(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Cgt(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Cgt_Un(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Ckfinite(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Clt(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Clt_Un(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}
	}
}
