using System;
using dnlib.DotNet.Emit;

namespace ControlFlow.Emulation {
	partial class Emulator {
		private const string TYPE_ERROR = "类型错误";
		private const string NOT_IMPL = "当前指令的模拟未实现";

		private bool Emulate(Instruction instruction) {
			if (instruction == null)
				throw new ArgumentNullException(nameof(instruction));

			switch (instruction.OpCode.Code) {
			case Code.Add:            return Emulate_Add(instruction);
			case Code.Add_Ovf:        return Emulate_Add_Ovf(instruction);
			case Code.Add_Ovf_Un:     return Emulate_Add_Ovf_Un(instruction);
			case Code.And:            return Emulate_And(instruction);
			case Code.Div:            return Emulate_Div(instruction);
			case Code.Div_Un:         return Emulate_Div_Un(instruction);
			case Code.Mul:            return Emulate_Mul(instruction);
			case Code.Mul_Ovf:        return Emulate_Mul_Ovf(instruction);
			case Code.Mul_Ovf_Un:     return Emulate_Mul_Ovf_Un(instruction);
			case Code.Neg:            return Emulate_Neg(instruction);
			case Code.Not:            return Emulate_Not(instruction);
			case Code.Or:             return Emulate_Or(instruction);
			case Code.Rem:            return Emulate_Rem(instruction);
			case Code.Rem_Un:         return Emulate_Rem_Un(instruction);
			case Code.Shl:            return Emulate_Shl(instruction);
			case Code.Shr:            return Emulate_Shr(instruction);
			case Code.Shr_Un:         return Emulate_Shr_Un(instruction);
			case Code.Sub:            return Emulate_Sub(instruction);
			case Code.Sub_Ovf:        return Emulate_Sub_Ovf(instruction);
			case Code.Sub_Ovf_Un:     return Emulate_Sub_Ovf_Un(instruction);
			case Code.Xor:            return Emulate_Xor(instruction);
			// 运算
			case Code.Ceq:            return Emulate_Ceq(instruction);
			case Code.Cgt:            return Emulate_Cgt(instruction);
			case Code.Cgt_Un:         return Emulate_Cgt_Un(instruction);
			case Code.Ckfinite:       return Emulate_Ckfinite(instruction);
			case Code.Clt:            return Emulate_Clt(instruction);
			case Code.Clt_Un:         return Emulate_Clt_Un(instruction);
			// 判断
			case Code.Box:            return Emulate_Box(instruction);
			case Code.Castclass:      return Emulate_Castclass(instruction);
			case Code.Conv_I:         return Emulate_Conv_I(instruction);
			case Code.Conv_I1:        return Emulate_Conv_I1(instruction);
			case Code.Conv_I2:        return Emulate_Conv_I2(instruction);
			case Code.Conv_I4:        return Emulate_Conv_I4(instruction);
			case Code.Conv_I8:        return Emulate_Conv_I8(instruction);
			case Code.Conv_Ovf_I:     return Emulate_Conv_Ovf_I(instruction);
			case Code.Conv_Ovf_I_Un:  return Emulate_Conv_Ovf_I_Un(instruction);
			case Code.Conv_Ovf_I1:    return Emulate_Conv_Ovf_I1(instruction);
			case Code.Conv_Ovf_I1_Un: return Emulate_Conv_Ovf_I1_Un(instruction);
			case Code.Conv_Ovf_I2:    return Emulate_Conv_Ovf_I2(instruction);
			case Code.Conv_Ovf_I2_Un: return Emulate_Conv_Ovf_I2_Un(instruction);
			case Code.Conv_Ovf_I4:    return Emulate_Conv_Ovf_I4(instruction);
			case Code.Conv_Ovf_I4_Un: return Emulate_Conv_Ovf_I4_Un(instruction);
			case Code.Conv_Ovf_I8:    return Emulate_Conv_Ovf_I8(instruction);
			case Code.Conv_Ovf_I8_Un: return Emulate_Conv_Ovf_I8_Un(instruction);
			case Code.Conv_Ovf_U:     return Emulate_Conv_Ovf_U(instruction);
			case Code.Conv_Ovf_U_Un:  return Emulate_Conv_Ovf_U_Un(instruction);
			case Code.Conv_Ovf_U1:    return Emulate_Conv_Ovf_U1(instruction);
			case Code.Conv_Ovf_U1_Un: return Emulate_Conv_Ovf_U1_Un(instruction);
			case Code.Conv_Ovf_U2:    return Emulate_Conv_Ovf_U2(instruction);
			case Code.Conv_Ovf_U2_Un: return Emulate_Conv_Ovf_U2_Un(instruction);
			case Code.Conv_Ovf_U4:    return Emulate_Conv_Ovf_U4(instruction);
			case Code.Conv_Ovf_U4_Un: return Emulate_Conv_Ovf_U4_Un(instruction);
			case Code.Conv_Ovf_U8:    return Emulate_Conv_Ovf_U8(instruction);
			case Code.Conv_Ovf_U8_Un: return Emulate_Conv_Ovf_U8_Un(instruction);
			case Code.Conv_R_Un:      return Emulate_Conv_R_Un(instruction);
			case Code.Conv_R4:        return Emulate_Conv_R4(instruction);
			case Code.Conv_R8:        return Emulate_Conv_R8(instruction);
			case Code.Conv_U:         return Emulate_Conv_U(instruction);
			case Code.Conv_U1:        return Emulate_Conv_U1(instruction);
			case Code.Conv_U2:        return Emulate_Conv_U2(instruction);
			case Code.Conv_U4:        return Emulate_Conv_U4(instruction);
			case Code.Conv_U8:        return Emulate_Conv_U8(instruction);
			case Code.Unbox:          return Emulate_Unbox(instruction);
			case Code.Unbox_Any:      return Emulate_Unbox_Any(instruction);
			// 转换
			case Code.Dup:            return Emulate_Dup(instruction);
			case Code.Ldarg:          return Emulate_Ldarg(instruction);
			case Code.Ldarga:         return Emulate_Ldarga(instruction);
			case Code.Ldc_I4:         return Emulate_Ldc_I4(instruction);
			case Code.Ldc_I8:         return Emulate_Ldc_I8(instruction);
			case Code.Ldc_R4:         return Emulate_Ldc_R4(instruction);
			case Code.Ldc_R8:         return Emulate_Ldc_R8(instruction);
			case Code.Ldelem:         return Emulate_Ldelem(instruction);
			case Code.Ldelem_I:       return Emulate_Ldelem_I(instruction);
			case Code.Ldelem_I1:      return Emulate_Ldelem_I1(instruction);
			case Code.Ldelem_I2:      return Emulate_Ldelem_I2(instruction);
			case Code.Ldelem_I4:      return Emulate_Ldelem_I4(instruction);
			case Code.Ldelem_I8:      return Emulate_Ldelem_I8(instruction);
			case Code.Ldelem_R4:      return Emulate_Ldelem_R4(instruction);
			case Code.Ldelem_R8:      return Emulate_Ldelem_R8(instruction);
			case Code.Ldelem_Ref:     return Emulate_Ldelem_Ref(instruction);
			case Code.Ldelem_U1:      return Emulate_Ldelem_U1(instruction);
			case Code.Ldelem_U2:      return Emulate_Ldelem_U2(instruction);
			case Code.Ldelem_U4:      return Emulate_Ldelem_U4(instruction);
			case Code.Ldelema:        return Emulate_Ldelema(instruction);
			case Code.Ldfld:          return Emulate_Ldfld(instruction);
			case Code.Ldflda:         return Emulate_Ldflda(instruction);
			case Code.Ldftn:          return Emulate_Ldftn(instruction);
			case Code.Ldind_I:        return Emulate_Ldind_I(instruction);
			case Code.Ldind_I1:       return Emulate_Ldind_I1(instruction);
			case Code.Ldind_I2:       return Emulate_Ldind_I2(instruction);
			case Code.Ldind_I4:       return Emulate_Ldind_I4(instruction);
			case Code.Ldind_I8:       return Emulate_Ldind_I8(instruction);
			case Code.Ldind_R4:       return Emulate_Ldind_R4(instruction);
			case Code.Ldind_R8:       return Emulate_Ldind_R8(instruction);
			case Code.Ldind_Ref:      return Emulate_Ldind_Ref(instruction);
			case Code.Ldind_U1:       return Emulate_Ldind_U1(instruction);
			case Code.Ldind_U2:       return Emulate_Ldind_U2(instruction);
			case Code.Ldind_U4:       return Emulate_Ldind_U4(instruction);
			case Code.Ldlen:          return Emulate_Ldlen(instruction);
			case Code.Ldloc:          return Emulate_Ldloc(instruction);
			case Code.Ldloca:         return Emulate_Ldloca(instruction);
			case Code.Ldnull:         return Emulate_Ldnull(instruction);
			case Code.Ldobj:          return Emulate_Ldobj(instruction);
			case Code.Ldsfld:         return Emulate_Ldsfld(instruction);
			case Code.Ldsflda:        return Emulate_Ldsflda(instruction);
			case Code.Ldstr:          return Emulate_Ldstr(instruction);
			case Code.Ldtoken:        return Emulate_Ldtoken(instruction);
			case Code.Ldvirtftn:      return Emulate_Ldvirtftn(instruction);
			case Code.Newarr:         return Emulate_Newarr(instruction);
			case Code.Newobj:         return Emulate_Newobj(instruction);
			case Code.Pop:            return Emulate_Pop(instruction);
			case Code.Starg:          return Emulate_Starg(instruction);
			case Code.Stelem:         return Emulate_Stelem(instruction);
			case Code.Stelem_I:       return Emulate_Stelem_I(instruction);
			case Code.Stelem_I1:      return Emulate_Stelem_I1(instruction);
			case Code.Stelem_I2:      return Emulate_Stelem_I2(instruction);
			case Code.Stelem_I4:      return Emulate_Stelem_I4(instruction);
			case Code.Stelem_I8:      return Emulate_Stelem_I8(instruction);
			case Code.Stelem_R4:      return Emulate_Stelem_R4(instruction);
			case Code.Stelem_R8:      return Emulate_Stelem_R8(instruction);
			case Code.Stelem_Ref:     return Emulate_Stelem_Ref(instruction);
			case Code.Stfld:          return Emulate_Stfld(instruction);
			case Code.Stind_I:        return Emulate_Stind_I(instruction);
			case Code.Stind_I1:       return Emulate_Stind_I1(instruction);
			case Code.Stind_I2:       return Emulate_Stind_I2(instruction);
			case Code.Stind_I4:       return Emulate_Stind_I4(instruction);
			case Code.Stind_I8:       return Emulate_Stind_I8(instruction);
			case Code.Stind_R4:       return Emulate_Stind_R4(instruction);
			case Code.Stind_R8:       return Emulate_Stind_R8(instruction);
			case Code.Stind_Ref:      return Emulate_Stind_Ref(instruction);
			case Code.Stloc:          return Emulate_Stloc(instruction);
			case Code.Stobj:          return Emulate_Stobj(instruction);
			case Code.Stsfld:         return Emulate_Stsfld(instruction);
			// 取值赋值
			case Code.Beq:            return Emulate_Beq(instruction);
			case Code.Bge:            return Emulate_Bge(instruction);
			case Code.Bge_Un:         return Emulate_Bge_Un(instruction);
			case Code.Bgt:            return Emulate_Bgt(instruction);
			case Code.Bgt_Un:         return Emulate_Bgt_Un(instruction);
			case Code.Ble:            return Emulate_Ble(instruction);
			case Code.Ble_Un:         return Emulate_Ble_Un(instruction);
			case Code.Blt:            return Emulate_Blt(instruction);
			case Code.Blt_Un:         return Emulate_Blt_Un(instruction);
			case Code.Bne_Un:         return Emulate_Bne_Un(instruction);
			case Code.Br:             return Emulate_Br(instruction);
			case Code.Brfalse:        return Emulate_Brfalse(instruction);
			case Code.Brtrue:         return Emulate_Brtrue(instruction);
			case Code.Endfilter:      return Emulate_Endfilter(instruction);
			case Code.Endfinally:     return Emulate_Endfinally(instruction);
			case Code.Leave:          return Emulate_Leave(instruction);
			case Code.Ret:            return Emulate_Ret(instruction);
			case Code.Rethrow:        return Emulate_Rethrow(instruction);
			case Code.Switch:         return Emulate_Switch(instruction);
			case Code.Throw:          return Emulate_Throw(instruction);
			// 分支
			case Code.Call:           return Emulate_Call(instruction);
			case Code.Calli:          return Emulate_Calli(instruction);
			case Code.Callvirt:       return Emulate_Callvirt(instruction);
			// 调用
			case Code.Arglist:        return Emulate_Arglist(instruction);
			case Code.Cpblk:          return Emulate_Cpblk(instruction);
			case Code.Cpobj:          return Emulate_Cpobj(instruction);
			case Code.Initblk:        return Emulate_Initblk(instruction);
			case Code.Initobj:        return Emulate_Initobj(instruction);
			case Code.Isinst:         return Emulate_Isinst(instruction);
			case Code.Localloc:       return Emulate_Localloc(instruction);
			case Code.Mkrefany:       return Emulate_Mkrefany(instruction);
			case Code.Refanytype:     return Emulate_Refanytype(instruction);
			case Code.Refanyval:      return Emulate_Refanyval(instruction);
			case Code.Sizeof:         return Emulate_Sizeof(instruction);
			// 其它
			default:                  UpdateStack(instruction); return true;
			}
		}

		/// <summary />
		protected virtual bool Emulate_Call(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Calli(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Callvirt(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Arglist(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Cpblk(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Cpobj(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Initblk(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Initobj(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Isinst(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Localloc(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Mkrefany(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Refanytype(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Refanyval(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Sizeof(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		private static void ThrowErrorType() {
			throw new InvalidOperationException(TYPE_ERROR);
		}

		private static void ThrowNotImpl() {
			throw new NotImplementedException(NOT_IMPL);
		}
	}
}
