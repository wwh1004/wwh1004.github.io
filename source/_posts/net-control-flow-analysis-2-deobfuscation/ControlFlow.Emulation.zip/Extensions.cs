using System;
using System.Collections.Generic;
using ControlFlow.Blocks;
using dnlib.DotNet.Emit;

namespace ControlFlow.Emulation {
	/// <summary>
	/// 扩展类
	/// </summary>
	public static class Extensions {
		/// <summary>
		/// 创建模拟器上下文
		/// </summary>
		/// <param name="methodBlock"></param>
		/// <returns></returns>
		public static EmulationContext CreateEmulationContext(this MethodBlock methodBlock) {
			if (methodBlock == null)
				throw new ArgumentNullException(nameof(methodBlock));

			return new EmulationContext(CreateVariables(methodBlock));
		}

		private static List<Local> CreateVariables(MethodBlock methodBlock) {
			VariablesGenerator generator;

			generator = new VariablesGenerator(methodBlock);
			generator.Generate();
			return generator.Variables;
		}

		private sealed class VariablesGenerator : BlockEnumerator {
			private readonly MethodBlock _methodBlock;
			private readonly List<Local> _variables;

			public List<Local> Variables => _variables;

			public VariablesGenerator(MethodBlock methodBlock) {
				if (methodBlock == null)
					throw new ArgumentNullException(nameof(methodBlock));

				_methodBlock = methodBlock;
				_variables = new List<Local>();
			}

			public void Generate() {
				Enumerate(_methodBlock);
			}

			protected override void OnBasicBlock(BasicBlock basicBlock) {
				foreach (Instruction instruction in basicBlock.Instructions) {
					switch (instruction.OpCode.Code) {
					case Code.Ldloc:
					case Code.Ldloca:
					case Code.Stloc:
						Local variable;

						variable = (Local)instruction.Operand;
						if (!_variables.Contains(variable))
							_variables.Add(variable);
						break;
					}
				}
			}
		}
	}
}
