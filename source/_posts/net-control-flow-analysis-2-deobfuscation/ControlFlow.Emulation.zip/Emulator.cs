using System;
using System.Collections.Generic;
using dnlib.DotNet.Emit;

namespace ControlFlow.Emulation {
	/*
	 * 虚拟机本身参考了de4dot的设计
	 * 
	 * 以下代码应与ControlFlow.Blocks项目没有任何关系
	 * 转换部分应该由扩展类Extensions完成
	 * 模拟器Emulator类只需要完成模拟的功能，不需要关心是什么样的Block
	 * 也不需要关心异常处理块是什么样的
	 * 只需要返回失败，由用户进行判断和处理
	 * 用户需要判断是何种原因造成了模拟的失败
	 * 
	 * 这个项目和ControlFlow.Blocks项目一样
	 * 需要先使用ControlFlow.Blocks.Extensions.SimplifyMacros(MethodDef)化简指令
	 * 否则可能模拟失败
	 */

	/// <summary>
	/// 模拟器上下文
	/// </summary>
	public sealed class EmulationContext {
		private readonly Dictionary<Local, IValue> _variables;
		private readonly Stack<IValue> _evaluationStack;

		/// <summary>
		/// 局部变量
		/// </summary>
		public Dictionary<Local, IValue> Variables => _variables;

		/// <summary>
		/// 计算堆栈
		/// </summary>
		public Stack<IValue> EvaluationStack => _evaluationStack;

		/// <summary>
		/// 构造器
		/// </summary>
		public EmulationContext() {
			_evaluationStack = new Stack<IValue>();
			_variables = new Dictionary<Local, IValue>();
		}

		/// <summary>
		/// 构造器
		/// </summary>
		/// <param name="variables"></param>
		public EmulationContext(IEnumerable<Local> variables) : this() {
			if (variables == null)
				throw new ArgumentNullException(nameof(variables));

			foreach (Local variable in variables)
				_variables.Add(variable, null);
		}

		private EmulationContext(Dictionary<Local, IValue> variables, Stack<IValue> evaluationStack) {
			if (variables == null)
				throw new ArgumentNullException(nameof(variables));
			if (evaluationStack == null)
				throw new ArgumentNullException(nameof(evaluationStack));

			_variables = variables;
			_evaluationStack = evaluationStack;
		}

		/// <summary>
		/// 克隆当前实例
		/// </summary>
		/// <returns></returns>
		public EmulationContext Clone() {
			IValue[] array;
			Stack<IValue> evaluationStack;
			Dictionary<Local, IValue> variables;

			array = _evaluationStack.ToArray();
			evaluationStack = new Stack<IValue>(_evaluationStack.Count);
			for (int i = array.Length - 1; i >= 0; i--)
				evaluationStack.Push(array[i].Clone());
			variables = new Dictionary<Local, IValue>(_variables.Count);
			foreach (KeyValuePair<Local, IValue> variable in _variables)
				variables.Add(variable.Key, variable.Value?.Clone());
			return new EmulationContext(variables, evaluationStack);
		}
	}

	/// <summary>
	/// 模拟器结果
	/// </summary>
	public sealed class EmulationResult {
		private readonly bool _success;
		private readonly Instruction _failedInstruction;
		private readonly Exception _exception;

		/// <summary>
		/// 是否成功
		/// </summary>
		public bool Success => _success;

		/// <summary>
		/// 模拟失败的指令
		/// </summary>
		public Instruction FailedInstruction => _failedInstruction;

		/// <summary>
		/// 异常（如果有）
		/// </summary>
		public Exception Exception => _exception;

		internal EmulationResult(bool success, Instruction failedInstruction, Exception exception) {
			_success = success;
			_failedInstruction = failedInstruction;
			_exception = exception;
		}
	}

	/// <summary>
	/// 指令模拟器
	/// </summary>
	public partial class Emulator {
		private EmulationContext _context;

		/// <summary>
		/// 上下文
		/// </summary>
		public EmulationContext Context {
			get => _context;
			set => _context = value;
		}

		/// <summary>
		/// 计算堆栈
		/// </summary>
		public Stack<IValue> EvaluationStack => _context.EvaluationStack;

		/// <summary>
		/// 局部变量
		/// </summary>
		public Dictionary<Local, IValue> Variables => _context.Variables;

		/// <summary>
		/// 构造器
		/// </summary>
		/// <param name="context"></param>
		public Emulator(EmulationContext context) {
			if (context == null)
				throw new ArgumentNullException(nameof(context));

			_context = context;
		}

		/// <summary>
		/// 模拟一段指令
		/// </summary>
		/// <param name="instructions"></param>
		/// <param name="startIndex"></param>
		/// <param name="length"></param>
		/// <returns></returns>
		public EmulationResult Emulate(IList<Instruction> instructions, int startIndex, int length) {
			if (instructions == null)
				throw new ArgumentNullException(nameof(instructions));
			if (startIndex < 0 || startIndex >= instructions.Count)
				throw new ArgumentOutOfRangeException(nameof(startIndex));
			if (length < 0 || startIndex + length > instructions.Count)
				throw new ArgumentOutOfRangeException(nameof(length));

			return Emulate(EnumerateInstructions(instructions, startIndex, length));
		}

		private static IEnumerable<Instruction> EnumerateInstructions(IList<Instruction> instructions, int startIndex, int length) {
			for (int i = startIndex; i < startIndex + length; i++)
				yield return instructions[i];
		}

		/// <summary>
		/// 模拟一段指令
		/// </summary>
		/// <param name="instructions"></param>
		/// <returns></returns>
		public EmulationResult Emulate(IEnumerable<Instruction> instructions) {
			if (instructions == null)
				throw new ArgumentNullException(nameof(instructions));

			foreach (Instruction instruction in instructions)
				try {
					if (!Emulate(instruction))
						return new EmulationResult(false, instruction, null);
				}
				catch (Exception ex) {
					return new EmulationResult(false, instruction, ex);
				}
			return new EmulationResult(true, null, null);
		}

		private void UpdateStack(Instruction instruction) {
			int pushes;
			int pops;

			instruction.CalculateStackUsage(out pushes, out pops);
			if (pops == -1)
				EvaluationStack.Clear();
			else {
				for (int i = 0; i < pops; i++)
					EvaluationStack.Pop();
				for (int i = 0; i < pushes; i++)
					EvaluationStack.Push(AnyValue.Unknown);
			}
		}
	}
}
