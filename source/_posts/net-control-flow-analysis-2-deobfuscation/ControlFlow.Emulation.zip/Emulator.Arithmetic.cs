using System;
using dnlib.DotNet.Emit;

namespace ControlFlow.Emulation {
	partial class Emulator {
		/// <summary />
		protected virtual bool Emulate_Add(Instruction instruction) {
			return Template_Arithmetic((x, y) => x + y, (x, y) => x + y);
		}

		/// <summary />
		protected virtual bool Emulate_Add_Ovf(Instruction instruction) {
			return Template_Arithmetic((x, y) => checked(x + y), (x, y) => checked(x + y));
		}

		/// <summary />
		protected virtual bool Emulate_Add_Ovf_Un(Instruction instruction) {
			return Template_Arithmetic((x, y) => (int)checked((uint)x + (uint)y), (x, y) => (long)checked((ulong)x + (ulong)y));
		}

		/// <summary />
		protected virtual bool Emulate_And(Instruction instruction) {
			return Template_Arithmetic((x, y) => x & y, (x, y) => x & y);
		}

		/// <summary />
		protected virtual bool Emulate_Div(Instruction instruction) {
			return Template_Arithmetic((x, y) => x / y, (x, y) => x / y);
		}

		/// <summary />
		protected virtual bool Emulate_Div_Un(Instruction instruction) {
			return Template_Arithmetic((x, y) => (int)((uint)x / (uint)y), (x, y) => (long)((ulong)x & (ulong)y));
		}

		/// <summary />
		protected virtual bool Emulate_Mul(Instruction instruction) {
			return Template_Arithmetic((x, y) => x * y, (x, y) => x * y);
		}

		/// <summary />
		protected virtual bool Emulate_Mul_Ovf(Instruction instruction) {
			return Template_Arithmetic((x, y) => checked(x * y), (x, y) => checked(x * y));
		}

		/// <summary />
		protected virtual bool Emulate_Mul_Ovf_Un(Instruction instruction) {
			return Template_Arithmetic((x, y) => (int)checked((uint)x * (uint)y), (x, y) => (long)checked((ulong)x * (ulong)y));
		}

		/// <summary />
		protected virtual bool Emulate_Neg(Instruction instruction) {
			return Template_Arithmetic(x => -x, x => -x);
		}

		/// <summary />
		protected virtual bool Emulate_Not(Instruction instruction) {
			return Template_Arithmetic(x => ~x, x => ~x);
		}

		/// <summary />
		protected virtual bool Emulate_Or(Instruction instruction) {
			return Template_Arithmetic((x, y) => x | y, (x, y) => x | y);
		}

		/// <summary />
		protected virtual bool Emulate_Rem(Instruction instruction) {
			return Template_Arithmetic((x, y) => x % y, (x, y) => x % y);
		}

		/// <summary />
		protected virtual bool Emulate_Rem_Un(Instruction instruction) {
			return Template_Arithmetic((x, y) => (int)((uint)x % (uint)y), (x, y) => (long)((ulong)x % (ulong)y));
		}

		/// <summary />
		protected virtual bool Emulate_Shl(Instruction instruction) {
			return Template_Arithmetic((x, y) => x << y, null);
		}

		/// <summary />
		protected virtual bool Emulate_Shr(Instruction instruction) {
			return Template_Arithmetic((x, y) => x >> y, null);
		}

		/// <summary />
		protected virtual bool Emulate_Shr_Un(Instruction instruction) {
			return Template_Arithmetic((x, y) => (int)((uint)x >> y), null);
		}

		/// <summary />
		protected virtual bool Emulate_Sub(Instruction instruction) {
			return Template_Arithmetic((x, y) => x - y, (x, y) => x - y);
		}

		/// <summary />
		protected virtual bool Emulate_Sub_Ovf(Instruction instruction) {
			return Template_Arithmetic((x, y) => checked(x - y), (x, y) => checked(x - y));
		}

		/// <summary />
		protected virtual bool Emulate_Sub_Ovf_Un(Instruction instruction) {
			return Template_Arithmetic((x, y) => (int)checked((uint)x - (uint)y), (x, y) => (long)checked((ulong)x - (ulong)y));
		}

		/// <summary />
		protected virtual bool Emulate_Xor(Instruction instruction) {
			return Template_Arithmetic((x, y) => x ^ y, (x, y) => x ^ y);
		}

		private bool Template_Arithmetic(Func<int, int> operation32, Func<long, long> operation64) {
			IValue x;
			IValue result;

			x = EvaluationStack.Pop();
			result = CheckAndTryGetUnknownValue_Arithmetic(x);
			if (result != null) {
				EvaluationStack.Push(result);
				return true;
			}
			if (x is Int32Value) {
				if (operation32 == null)
					ThrowNotImpl();
				result = new Int32Value(operation32(((Int32Value)x).Int32));
			}
			else {
				if (operation32 == null)
					ThrowNotImpl();
				result = new Int64Value(operation64(GetInt64_Arithmetic(x)));
			}
			EvaluationStack.Push(result);
			return true;
		}

		private bool Template_Arithmetic(Func<int, int, int> operation32, Func<long, long, long> operation64) {
			IValue x;
			IValue y;
			IValue result;

			y = EvaluationStack.Pop();
			x = EvaluationStack.Pop();
			result = CheckAndTryGetUnknownValue_Arithmetic(x, y);
			if (result != null) {
				EvaluationStack.Push(result);
				return true;
			}
			if (x is Int32Value && y is Int32Value) {
				if (operation32 == null)
					ThrowNotImpl();
				result = new Int32Value(operation32(((Int32Value)x).Int32, ((Int32Value)y).Int32));
			}
			else {
				if (operation32 == null)
					ThrowNotImpl();
				result = new Int64Value(operation64(GetInt64_Arithmetic(x), GetInt64_Arithmetic(y)));
			}
			EvaluationStack.Push(result);
			return true;
		}

		private static IValue CheckAndTryGetUnknownValue_Arithmetic(IValue x) {
			if (!(x is Int32Value) && !(x is Int64Value))
				ThrowErrorType();
			if (x.Type == ValueType.Unknown)
				return x is Int32Value ? (IValue)Int32Value.Unknown : Int64Value.Unknown;
			else
				return null;
		}

		private static IValue CheckAndTryGetUnknownValue_Arithmetic(IValue x, IValue y) {
			if ((!(x is Int32Value) && !(x is Int64Value)) || (!(y is Int32Value) && !(y is Int64Value)))
				ThrowErrorType();
			if (x.Type == ValueType.Unknown || y.Type == ValueType.Unknown)
				return x is Int32Value ? (IValue)Int32Value.Unknown : Int64Value.Unknown;
			else
				return null;
		}

		private static long GetInt64_Arithmetic(IValue value) {
			return value is Int32Value ? ((Int32Value)value).Int32 : ((Int64Value)value).Int64;
		}
	}
}
