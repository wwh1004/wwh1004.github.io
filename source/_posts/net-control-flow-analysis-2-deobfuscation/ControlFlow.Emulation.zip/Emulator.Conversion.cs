using dnlib.DotNet.Emit;

namespace ControlFlow.Emulation {
	partial class Emulator {
		/// <summary />
		protected virtual bool Emulate_Box(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Castclass(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_I(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_I1(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_I2(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_I4(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_I8(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_I(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_I_Un(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_I1(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_I1_Un(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_I2(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_I2_Un(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_I4(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_I4_Un(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_I8(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_I8_Un(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_U(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_U_Un(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_U1(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_U1_Un(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_U2(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_U2_Un(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_U4(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_U4_Un(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_U8(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_Ovf_U8_Un(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_R_Un(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_R4(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_R8(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_U(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_U1(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_U2(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_U4(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Conv_U8(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Unbox(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}

		/// <summary />
		protected virtual bool Emulate_Unbox_Any(Instruction instruction) {
			UpdateStack(instruction);
			return true;
		}
	}
}
