using System;
using System.Collections.Generic;

namespace ControlFlow.Blocks {
	/// <summary>
	/// 块迭代器
	/// </summary>
	public abstract class BlockEnumerator {
		/// <summary>
		/// 迭代
		/// </summary>
		/// <param name="blocks"></param>
		protected void Enumerate(IEnumerable<IBlock> blocks) {
			if (blocks == null)
				throw new ArgumentNullException(nameof(blocks));

			foreach (IBlock block in blocks)
				Enumerate(block);
		}

		/// <summary>
		/// 迭代
		/// </summary>
		/// <param name="block"></param>
		protected void Enumerate(IBlock block) {
			if (block == null)
				throw new ArgumentNullException(nameof(block));

			if (block is BasicBlock)
				OnBasicBlock((BasicBlock)block);
			else if (block is TryBlock) {
				TryBlock tryBlock;

				tryBlock = (TryBlock)block;
				OnScopeBlockEnter(tryBlock);
				OnTryBlockEnter(tryBlock);
				Enumerate(tryBlock.Blocks);
				OnTryBlockLeave(tryBlock);
				OnScopeBlockLeave(tryBlock);
				Enumerate(tryBlock.Handlers);
			}
			else if (block is FilterBlock) {
				FilterBlock filterBlock;

				filterBlock = (FilterBlock)block;
				OnScopeBlockEnter(filterBlock);
				OnFilterBlockEnter(filterBlock);
				Enumerate(filterBlock.Blocks);
				OnFilterBlockLeave(filterBlock);
				OnScopeBlockLeave(filterBlock);
				Enumerate(filterBlock.Handler);
			}
			else if (block is HandlerBlock) {
				HandlerBlock handlerBlock;

				handlerBlock = (HandlerBlock)block;
				OnScopeBlockEnter(handlerBlock);
				OnHandlerBlockEnter(handlerBlock);
				Enumerate(handlerBlock.Blocks);
				OnHandlerBlockLeave(handlerBlock);
				OnScopeBlockLeave(handlerBlock);
			}
			else if (block is MethodBlock) {
				MethodBlock methodBlock;

				methodBlock = (MethodBlock)block;
				OnScopeBlockEnter(methodBlock);
				OnMethodBlockEnter(methodBlock);
				Enumerate(methodBlock.Blocks);
				OnMethodBlockLeave(methodBlock);
				OnScopeBlockLeave(methodBlock);
			}
			else
				throw new InvalidOperationException();
		}

		/// <summary>
		/// 在出现基本块时发生
		/// </summary>
		/// <param name="basicBlock"></param>
		protected virtual void OnBasicBlock(BasicBlock basicBlock) {
		}

		/// <summary>
		/// 在进入Scope块前发生
		/// </summary>
		/// <param name="scopeBlock"></param>
		protected virtual void OnScopeBlockEnter(ScopeBlock scopeBlock) {
		}

		/// <summary>
		/// 在离开Scope块后发生
		/// </summary>
		/// <param name="scopeBlock"></param>
		protected virtual void OnScopeBlockLeave(ScopeBlock scopeBlock) {
		}

		/// <summary>
		/// 在进入Try块前发生
		/// </summary>
		/// <param name="tryBlock"></param>
		protected virtual void OnTryBlockEnter(TryBlock tryBlock) {
		}

		/// <summary>
		/// 在离开Try块后发生
		/// </summary>
		/// <param name="tryBlock"></param>
		protected virtual void OnTryBlockLeave(TryBlock tryBlock) {
		}

		/// <summary>
		/// 在进入Filter块前发生
		/// </summary>
		/// <param name="filterBlock"></param>
		protected virtual void OnFilterBlockEnter(FilterBlock filterBlock) {
		}

		/// <summary>
		/// 在离开Filter块后发生
		/// </summary>
		/// <param name="filterBlock"></param>
		protected virtual void OnFilterBlockLeave(FilterBlock filterBlock) {
		}

		/// <summary>
		/// 在进入Handler块前发生
		/// </summary>
		/// <param name="handlerBlock"></param>
		protected virtual void OnHandlerBlockEnter(HandlerBlock handlerBlock) {
		}

		/// <summary>
		/// 在离开Handler块后发生
		/// </summary>
		/// <param name="handlerBlock"></param>
		protected virtual void OnHandlerBlockLeave(HandlerBlock handlerBlock) {
		}

		/// <summary>
		/// 在进入Method块前发生
		/// </summary>
		/// <param name="methodBlock"></param>
		protected virtual void OnMethodBlockEnter(MethodBlock methodBlock) {
		}

		/// <summary>
		/// 在离开Method块后发生
		/// </summary>
		/// <param name="methodBlock"></param>
		protected virtual void OnMethodBlockLeave(MethodBlock methodBlock) {
		}
	}
}
