using System;
using System.Collections.Generic;
using System.Diagnostics;
using dnlib.DotNet;
using dnlib.DotNet.Emit;

namespace ControlFlow.Blocks {
	/// <summary>
	/// 从指令列表到块的转换器
	/// </summary>
	public sealed class BlockParser {
		private readonly IList<Instruction> _instructions;
		private readonly IList<ExceptionHandler> _exceptionHandlers;
		private readonly IList<Local> _variables;
		private Dictionary<Instruction, int> _instructionDictionary;
		private ExceptionHandlerInfo[] _exceptionHandlerInfos;
		private LinkedExceptionHandlerInfo _linkedExceptionHandlerInfoRoot;
		private bool[] _isEntrys;
		private int[] _blockLengths;
		private BasicBlock[] _basicBlocks;
		private IBlock[] _blocks;
		private BasicBlock[] _basicBlocksNonNull;
		private MethodBlock _methodBlock;
		private bool _isParsed;

		/// <summary>
		/// 所有基本块
		/// </summary>
		public BasicBlock[] BasicBlocks {
			get {
				if (!_isParsed)
					throw new InvalidOperationException();

				return _basicBlocksNonNull;
			}
		}

		/// <summary>
		/// 方法块
		/// </summary>
		public MethodBlock MethodBlock {
			get {
				if (!_isParsed)
					throw new InvalidOperationException();

				return _methodBlock;
			}
		}

		/// <summary>
		/// 构造器
		/// </summary>
		/// <param name="instructions"></param>
		/// <param name="exceptionHandlers"></param>
		/// <param name="variables"></param>
		public BlockParser(IList<Instruction> instructions, IList<ExceptionHandler> exceptionHandlers, IList<Local> variables) {
			if (instructions == null)
				throw new ArgumentNullException(nameof(instructions));
			if (exceptionHandlers == null)
				throw new ArgumentNullException(nameof(exceptionHandlers));
			if (variables == null)
				throw new ArgumentNullException(nameof(variables));
			if (HasNotSupportedInstruction(instructions))
				throw new NotSupportedException("存在不受支持的指令。");

			_instructions = instructions;
			_exceptionHandlers = exceptionHandlers;
			_variables = variables;
		}

		/// <summary>
		/// 转换
		/// </summary>
		/// <param name="toMethodBlock">是否生成 <see cref="MethodBlock"/></param>
		public void Parse(bool toMethodBlock) {
			if (_isParsed)
				return;
			_instructionDictionary = ToDictionary(_instructions);
			_exceptionHandlerInfos = CreateExceptionHandlerInfos(_exceptionHandlers, _instructionDictionary);
			// 一定不能对异常处理块进行排序
			// 否则处理这样的代码可能导致排序后语义改变：
			// class Exception3 : Exception2 {
			// }
			// class Exception2 : Exception {
			// }
			// ...
			// ...
			// try {
			//     throw new Exception3();
			// }
			// catch (Exception3) {
			//     Console.WriteLine("3");
			// }
			// catch (Exception2) {
			//     Console.WriteLine("2");
			// }
			ToBasicBlocks();
			if (toMethodBlock)
				ToMethodBlock();
			_isParsed = true;
		}

		private void ToBasicBlocks() {
			AnalyzeEntrys();
			// 我们不能把分析入口和分析引用放在一起，因为入口是不确定的，有可能会导致已经识别出的块被截断（有指令会跳转到已识别块中间的指令，而不是开头）
			AnalyzeReferencesAndCreateBasicBlocks();
			// 使用DFS分析引用，去除未使用的块
			AddBranchs();
			// 添加分支
			CreateBasicBlocksNonNull();
		}

		private void AnalyzeEntrys() {
			_isEntrys = new bool[_instructions.Count];
			_isEntrys[0] = true;
			for (int i = 0; i < _instructions.Count; i++) {
				Instruction instruction;

				instruction = _instructions[i];
				switch (instruction.OpCode.FlowControl) {
				case FlowControl.Branch:
				case FlowControl.Cond_Branch:
				case FlowControl.Return:
				case FlowControl.Throw:
					if (i + 1 != _instructions.Count)
						// 如果当前不是最后一条指令，那么下一条指令就是新入口
						_isEntrys[i + 1] = true;
					if (instruction.OpCode.OperandType == OperandType.InlineBrTarget)
						// brX
						_isEntrys[_instructionDictionary[(Instruction)instruction.Operand]] = true;
					else if (instruction.OpCode.OperandType == OperandType.InlineSwitch)
						// switch
						foreach (Instruction target in (IEnumerable<Instruction>)instruction.Operand)
							_isEntrys[_instructionDictionary[target]] = true;
					break;
				}
			}
			foreach (ExceptionHandlerInfo exceptionHandlerInfo in _exceptionHandlerInfos) {
				_isEntrys[exceptionHandlerInfo.TryStartIndex] = true;
				if (exceptionHandlerInfo.TryEndIndex != _instructions.Count)
					_isEntrys[exceptionHandlerInfo.TryEndIndex] = true;
				// try
				if (exceptionHandlerInfo.FilterStartIndex != -1)
					_isEntrys[exceptionHandlerInfo.FilterStartIndex] = true;
				// filter
				_isEntrys[exceptionHandlerInfo.HandlerStartIndex] = true;
				if (exceptionHandlerInfo.HandlerEndIndex != _instructions.Count)
					_isEntrys[exceptionHandlerInfo.HandlerEndIndex] = true;
				// handler
			}
		}

		private void AnalyzeReferencesAndCreateBasicBlocks() {
			_blockLengths = new int[_instructions.Count];
			_basicBlocks = new BasicBlock[_instructions.Count];
			AnalyzeReferencesAndCreateBasicBlocks(0);
			// 从入口开始分析引用
			while (true) {
				bool isModified;

				isModified = false;
				foreach (ExceptionHandlerInfo exceptionHandlerInfo in _exceptionHandlerInfos) {
					// 分析完入口之后，我们还要在此基础上分析异常处理块，如果异常处理块的Try块入口被引用，那么说明Filter/Handler块也被引用
					// 不存在跳转语句直接跳入Try块内部而不是Try块的入口，这种情况是非法的
					if (exceptionHandlerInfo.IsVisited || _blockLengths[exceptionHandlerInfo.TryStartIndex] == 0)
						continue;
					exceptionHandlerInfo.IsVisited = true;
					isModified = true;
					if (exceptionHandlerInfo.FilterStartIndex != -1)
						AnalyzeReferencesAndCreateBasicBlocks(exceptionHandlerInfo.FilterStartIndex);
					// filter
					AnalyzeReferencesAndCreateBasicBlocks(exceptionHandlerInfo.HandlerStartIndex);
					// handler
				}
				if (!isModified)
					break;
			}
		}

		private void AnalyzeReferencesAndCreateBasicBlocks(int startIndex) {
			if (!_isEntrys[startIndex])
				throw new InvalidOperationException("入口识别出错。");

			int exitIndex;
			Instruction exit;
			int nextEntryIndex;

			exitIndex = FindExitIndex(startIndex, out _blockLengths[startIndex]);
			_basicBlocks[startIndex] = new BasicBlock(EnumerateInstructions(startIndex, _blockLengths[startIndex]));
			exit = _instructions[exitIndex];
			switch (exit.OpCode.FlowControl) {
			case FlowControl.Branch:
				// 分支块被引用
				nextEntryIndex = _instructionDictionary[(Instruction)exit.Operand];
				if (_blockLengths[nextEntryIndex] == 0)
					// 分支块未被分析
					AnalyzeReferencesAndCreateBasicBlocks(nextEntryIndex);
				break;
			case FlowControl.Cond_Branch:
				// 下一个块和分支块被引用
				nextEntryIndex = exitIndex + 1;
				if (nextEntryIndex < _instructions.Count && _blockLengths[nextEntryIndex] == 0)
					// 下一条指令就是未分析的新块的入口
					AnalyzeReferencesAndCreateBasicBlocks(nextEntryIndex);
				if (exit.OpCode.OperandType == OperandType.InlineBrTarget) {
					// bxx
					nextEntryIndex = _instructionDictionary[(Instruction)exit.Operand];
					if (_blockLengths[nextEntryIndex] == 0)
						AnalyzeReferencesAndCreateBasicBlocks(nextEntryIndex);
				}
				else if (exit.OpCode.OperandType == OperandType.InlineSwitch) {
					// switch
					foreach (Instruction nextEntry in (IEnumerable<Instruction>)exit.Operand) {
						nextEntryIndex = _instructionDictionary[nextEntry];
						if (_blockLengths[nextEntryIndex] == 0)
							AnalyzeReferencesAndCreateBasicBlocks(nextEntryIndex);
					}
				}
				break;
			case FlowControl.Call:
			case FlowControl.Next:
				// 下一个块被引用
				nextEntryIndex = exitIndex + 1;
				if (_blockLengths[nextEntryIndex] == 0)
					// 我们不需要判断是否到了结尾
					// 如果没ret，br，throw之类的指令就到了块的结尾，说明这个方法体的控制流是有问题的
					AnalyzeReferencesAndCreateBasicBlocks(nextEntryIndex);
				break;
			}
		}

		private int FindExitIndex(int entryIndex, out int blockLength) {
			if (!_isEntrys[entryIndex])
				throw new InvalidOperationException("入口识别出错。");

			int exitIndex;

			exitIndex = _instructions.Count - 1;
			for (int i = entryIndex + 1; i < _instructions.Count; i++)
				if (_isEntrys[i]) {
					exitIndex = i - 1;
					break;
				}
			blockLength = exitIndex - entryIndex + 1;
			return exitIndex;
		}

		private IEnumerable<Instruction> EnumerateInstructions(int startIndex, int length) {
			for (int i = startIndex; i < startIndex + length; i++)
				yield return _instructions[i];
		}

		private void AddBranchs() {
			BasicBlock nextBasicBlock;

			nextBasicBlock = null;
			for (int i = _basicBlocks.Length - 1; i >= 0; i--) {
				BasicBlock basicBlock;
				List<Instruction> instructions;
				int lastInstructionIndex;
				Instruction lastInstruction;

				basicBlock = _basicBlocks[i];
				if (basicBlock == null)
					continue;
				instructions = basicBlock.Instructions;
				lastInstructionIndex = instructions.Count - 1;
				lastInstruction = instructions[lastInstructionIndex];
				switch (lastInstruction.OpCode.FlowControl) {
				case FlowControl.Branch:
					basicBlock.BranchOpcode = lastInstruction.OpCode;
					basicBlock.FallThrough = _basicBlocks[_instructionDictionary[(Instruction)lastInstruction.Operand]];
					instructions.RemoveAt(lastInstructionIndex);
					break;
				case FlowControl.Cond_Branch:
					if (nextBasicBlock == null)
						// nextBasicBlock不应该为null，因为在此之前我们已经移除了无效代码
						throw new InvalidOperationException();
					basicBlock.BranchOpcode = lastInstruction.OpCode;
					basicBlock.FallThrough = nextBasicBlock;
					if (lastInstruction.OpCode.Code == Code.Switch) {
						Instruction[] switchTargets;

						switchTargets = (Instruction[])lastInstruction.Operand;
						basicBlock.SwitchTargets = new List<BasicBlock>(switchTargets.Length);
						for (int j = 0; j < switchTargets.Length; j++)
							basicBlock.SwitchTargets.Add(_basicBlocks[_instructionDictionary[switchTargets[j]]]);
					}
					else
						basicBlock.ConditionalTarget = _basicBlocks[_instructionDictionary[(Instruction)lastInstruction.Operand]];
					instructions.RemoveAt(lastInstructionIndex);
					break;
				case FlowControl.Call:
				case FlowControl.Next:
					if (nextBasicBlock == null)
						throw new InvalidOperationException();
					basicBlock.BranchOpcode = OpCodes.Br;
					basicBlock.FallThrough = nextBasicBlock;
					break;
				case FlowControl.Return:
				case FlowControl.Throw:
					basicBlock.BranchOpcode = lastInstruction.OpCode;
					instructions.RemoveAt(lastInstructionIndex);
					break;
				}
				nextBasicBlock = basicBlock;
			}
		}

		private void CreateBasicBlocksNonNull() {
			int nonNullCount;

			nonNullCount = 0;
			foreach (BasicBlock basicBlock in _basicBlocks)
				if (basicBlock != null)
					nonNullCount++;
			_basicBlocksNonNull = new BasicBlock[nonNullCount];
			nonNullCount = 0;
			for (int i = 0; i < _basicBlocks.Length; i++)
				if (_basicBlocks[i] == null)
					nonNullCount++;
				else
					_basicBlocksNonNull[i - nonNullCount] = _basicBlocks[i];
		}

		private void ToMethodBlock() {
			CopyBlocks();
			if (HasReferencedExceptionHandler()) {
				AnalyzeExceptionHandlers();
				CombineExceptionHandlers();
			}
			CreateMethodBlock();
		}

		private void CopyBlocks() {
			_blocks = new IBlock[_basicBlocks.Length];
			for (int i = 0; i < _basicBlocks.Length; i++)
				_blocks[i] = _basicBlocks[i];
		}

		private bool HasReferencedExceptionHandler() {
			foreach (ExceptionHandlerInfo exceptionHandlerInfo in _exceptionHandlerInfos)
				if (exceptionHandlerInfo.IsVisited)
					return true;
			return false;
		}

		private void AnalyzeExceptionHandlers() {
			_linkedExceptionHandlerInfoRoot = new LinkedExceptionHandlerInfo(new ExceptionHandlerInfo(0, int.MaxValue));
			// 创建Dummy
			foreach (ExceptionHandlerInfo exceptionHandlerInfo in _exceptionHandlerInfos) {
				bool isTryEqual;
				LinkedExceptionHandlerInfo scope;

				if (!exceptionHandlerInfo.IsVisited) {
					Debug.Assert(false);
					// 正常情况下我们不会遇到无效异常处理信息，目前也没有壳会加入无效异常处理信息
					continue;
				}
				scope = _linkedExceptionHandlerInfoRoot.FindParent(exceptionHandlerInfo, out isTryEqual);
				if (isTryEqual)
					scope.Handlers.Add(exceptionHandlerInfo);
				else {
					List<LinkedExceptionHandlerInfo> children;
					LinkedExceptionHandlerInfo child;

					children = scope.Children;
					child = new LinkedExceptionHandlerInfo(exceptionHandlerInfo);
					if (!scope.HasChildren)
						children.Add(child);
					else {
						int subChildCount;

						subChildCount = 0;
						for (int i = 0; i < children.Count; i++) {
							LinkedExceptionHandlerInfo subChild;

							subChild = children[i];
							// 判断child是否为某个subChild的scope
							if (child.TryInfo.HasChild(subChild.TryInfo)) {
								child.Children.Add(subChild);
								subChildCount++;
							}
							else
								// 将subChild提前
								children[i - subChildCount] = subChild;
						}
						children.RemoveRange(children.Count - subChildCount, subChildCount);
						children.Add(child);
					}
				}
			}
		}

		private void CombineExceptionHandlers() {
			foreach (LinkedExceptionHandlerInfo linkedExceptionHandlerInfo in _linkedExceptionHandlerInfoRoot.Children)
				CombineExceptionHandlers(linkedExceptionHandlerInfo);
		}

		private void CombineExceptionHandlers(LinkedExceptionHandlerInfo linkedExceptionHandlerInfo) {
			ExceptionHandlerInfo tryInfo;
			TryBlock tryBlock;

			if (linkedExceptionHandlerInfo.HasChildren)
				// 找到最小异常处理块
				foreach (LinkedExceptionHandlerInfo child in linkedExceptionHandlerInfo.Children)
					CombineExceptionHandlers(child);
			tryInfo = linkedExceptionHandlerInfo.TryInfo;
			tryBlock = new TryBlock(EnumerateNonNullBlocks(tryInfo.TryStartIndex, tryInfo.TryEndIndex));
			RemoveBlocks(tryInfo.TryStartIndex, tryInfo.TryEndIndex);
			_blocks[tryInfo.TryStartIndex] = tryBlock;
			// try
			foreach (ExceptionHandlerInfo handlerInfo in linkedExceptionHandlerInfo.Handlers) {
				AddHandler(tryBlock, handlerInfo);
				RemoveBlocks(handlerInfo.FilterStartIndex == -1 ? handlerInfo.HandlerStartIndex : handlerInfo.FilterStartIndex, handlerInfo.HandlerEndIndex);
			}
			// filter/handler
		}

		private void RemoveBlocks(int startIndex, int endIndex) {
			for (int i = startIndex; i < endIndex; i++)
				_blocks[i] = null;
		}

		private void AddHandler(TryBlock tryBlock, ExceptionHandlerInfo exceptionHandlerInfo) {
			if (exceptionHandlerInfo.FilterStartIndex == -1)
				tryBlock.Handlers.Add(new HandlerBlock(EnumerateNonNullBlocks(exceptionHandlerInfo.HandlerStartIndex, exceptionHandlerInfo.HandlerEndIndex), exceptionHandlerInfo.HandlerType, exceptionHandlerInfo.CatchType));
			else
				tryBlock.Handlers.Add(new FilterBlock(EnumerateNonNullBlocks(exceptionHandlerInfo.FilterStartIndex, exceptionHandlerInfo.HandlerStartIndex), new HandlerBlock(EnumerateNonNullBlocks(exceptionHandlerInfo.HandlerStartIndex, exceptionHandlerInfo.HandlerEndIndex), ScopeBlockType.Catch, null)));
		}

		private IEnumerable<IBlock> EnumerateNonNullBlocks(int startIndex, int endIndex) {
			for (int i = startIndex; i < endIndex; i++)
				if (_blocks[i] != null)
					yield return _blocks[i];
		}

		private void CreateMethodBlock() {
			_methodBlock = new MethodBlock(EnumerateNonNullBlocks(0, _blocks.Length), _variables);
			SetBlockScope(_methodBlock.Blocks, _methodBlock);
		}

		private static void SetBlockScope(IEnumerable<IBlock> blocks, IBlock scope) {
			foreach (IBlock block in blocks)
				if (block is BasicBlock)
					block.Scope = scope;
				else if (block is TryBlock) {
					TryBlock tryBlock;

					tryBlock = (TryBlock)block;
					tryBlock.Scope = scope;
					SetBlockScope(tryBlock.Blocks, tryBlock);
					SetBlockScope(tryBlock.Handlers, scope);
				}
				else if (block is FilterBlock) {
					FilterBlock filterBlock;

					filterBlock = (FilterBlock)block;
					filterBlock.Scope = scope;
					SetBlockScope(filterBlock.Blocks, filterBlock);
					filterBlock.Handler.Scope = scope;
					SetBlockScope(filterBlock.Handler.Blocks, filterBlock.Handler);
				}
				else {
					ScopeBlock scopeBlock;

					scopeBlock = (ScopeBlock)block;
					scopeBlock.Scope = scope;
					SetBlockScope(scopeBlock.Blocks, block);
				}
		}

		private static bool HasNotSupportedInstruction(IEnumerable<Instruction> instructions) {
			foreach (Instruction instruction in instructions)
				switch (instruction.OpCode.Code) {
				case Code.Jmp:
					return true;
				}
			return false;
		}

		private static Dictionary<T, int> ToDictionary<T>(IList<T> list) {
			Dictionary<T, int> dictionary;

			dictionary = new Dictionary<T, int>(list.Count);
			for (int i = 0; i < list.Count; i++)
				dictionary.Add(list[i], i);
			return dictionary;
		}

		private static ExceptionHandlerInfo[] CreateExceptionHandlerInfos(IList<ExceptionHandler> exceptionHandlers, Dictionary<Instruction, int> instructionDictionary) {
			ExceptionHandlerInfo[] exceptionHandlerInfos;

			exceptionHandlerInfos = new ExceptionHandlerInfo[exceptionHandlers.Count];
			for (int i = 0; i < exceptionHandlerInfos.Length; i++)
				exceptionHandlerInfos[i] = new ExceptionHandlerInfo(exceptionHandlers[i], instructionDictionary);
			return exceptionHandlerInfos;
		}

		[DebuggerDisplay("TS:{TryStartIndex} TE:{TryEndIndex} FS:{FilterStartIndex} HS:{HandlerStartIndex} HE:{HandlerEndIndex} T:{HandlerType}")]
		private sealed class ExceptionHandlerInfo {
			private readonly int _tryStartIndex;
			private readonly int _tryEndIndex;
			private readonly int _filterStartIndex;
			private readonly int _handlerStartIndex;
			private readonly int _handlerEndIndex;
			private readonly ITypeDefOrRef _catchType;
			private readonly ScopeBlockType _handlerType;
			private bool _isVisited;

			public int TryStartIndex => _tryStartIndex;

			public int TryEndIndex => _tryEndIndex;

			public int FilterStartIndex => _filterStartIndex;

			public int HandlerStartIndex => _handlerStartIndex;

			public int HandlerEndIndex => _handlerEndIndex;

			public ITypeDefOrRef CatchType => _catchType;

			public ScopeBlockType HandlerType => _handlerType;

			public bool IsVisited {
				get => _isVisited;
				set => _isVisited = value;
			}

			public ExceptionHandlerInfo(ExceptionHandler exceptionHandler, Dictionary<Instruction, int> instructionDictionary) {
				_tryStartIndex = instructionDictionary[exceptionHandler.TryStart];
				if (exceptionHandler.TryEnd == null)
					_tryEndIndex = instructionDictionary.Count;
				else
					_tryEndIndex = instructionDictionary[exceptionHandler.TryEnd];
				// try
				if (exceptionHandler.FilterStart == null)
					_filterStartIndex = -1;
				else
					_filterStartIndex = instructionDictionary[exceptionHandler.FilterStart];
				// filter
				_handlerStartIndex = instructionDictionary[exceptionHandler.HandlerStart];
				if (exceptionHandler.HandlerEnd == null)
					_handlerEndIndex = instructionDictionary.Count;
				else
					_handlerEndIndex = instructionDictionary[exceptionHandler.HandlerEnd];
				// handler
				_catchType = exceptionHandler.CatchType;
				switch (exceptionHandler.HandlerType) {
				case ExceptionHandlerType.Catch:
					_handlerType = ScopeBlockType.Catch;
					break;
				case ExceptionHandlerType.Filter:
					_handlerType = ScopeBlockType.Filter;
					break;
				case ExceptionHandlerType.Finally:
					_handlerType = ScopeBlockType.Finally;
					break;
				case ExceptionHandlerType.Fault:
					_handlerType = ScopeBlockType.Fault;
					break;
				default:
					throw new NotSupportedException();
				}
			}

			/// <summary>
			/// Dummy
			/// </summary>
			/// <param name="tryStartIndex"></param>
			/// <param name="tryEndIndex"></param>
			public ExceptionHandlerInfo(int tryStartIndex, int tryEndIndex) {
				_tryStartIndex = tryStartIndex;
				_tryEndIndex = tryEndIndex;
			}

			public bool IsTryEqual(ExceptionHandlerInfo exceptionHandlerInfo) {
				return exceptionHandlerInfo.TryStartIndex == TryStartIndex && exceptionHandlerInfo.TryEndIndex == TryEndIndex;
			}

			public bool HasChild(ExceptionHandlerInfo child) {
				// 如果child的try在scope的try/filter/handler内，那么child的handler也在之内
				// 否则这是一个非法的方法体
				if (child.TryStartIndex >= TryStartIndex && child.TryEndIndex <= TryEndIndex)
					// try in try
					return true;
				if (child.TryStartIndex >= (FilterStartIndex == -1 ? HandlerStartIndex : FilterStartIndex) && child.TryEndIndex <= HandlerEndIndex)
					// try in filter/handler
					return true;
				return false;
			}
		}

		[DebuggerDisplay("TS:{Value.TryStartIndex} TE:{Value.TryEndIndex} CC:{Children.Count} HC:{Handlers.Count}")]
		[DebuggerTypeProxy(typeof(DebugView))]
		private sealed class LinkedExceptionHandlerInfo {
			private readonly ExceptionHandlerInfo _value;
			private readonly List<ExceptionHandlerInfo> _handlers;
			private List<LinkedExceptionHandlerInfo> _children;

			public ExceptionHandlerInfo TryInfo => _value;

			public List<ExceptionHandlerInfo> Handlers => _handlers;

			public bool HasChildren => _children != null && _children.Count != 0;

			public List<LinkedExceptionHandlerInfo> Children {
				get {
					if (_children == null)
						_children = new List<LinkedExceptionHandlerInfo>();
					return _children;
				}
			}

			public LinkedExceptionHandlerInfo(ExceptionHandlerInfo value) {
				if (value == null)
					throw new ArgumentNullException(nameof(value));

				_value = value;
				_handlers = new List<ExceptionHandlerInfo> {
					value
				};
			}

			public LinkedExceptionHandlerInfo FindParent(ExceptionHandlerInfo child, out bool isTryEqual) {
				isTryEqual = _value.IsTryEqual(child);
				if (isTryEqual)
					// 如果try块相等，只是handler块不同，直接返回自身
					return this;
				if (!_value.HasChild(child))
					return null;
				if (!HasChildren)
					// 如果当前没有子信息，直接返回自身
					return this;
				foreach (LinkedExceptionHandlerInfo scope in _children) {
					// 有子信息，所以我们要搜索，找到最小范围
					LinkedExceptionHandlerInfo result;

					result = scope.FindParent(child, out isTryEqual);
					if (result != null)
						return result;
				}
				return this;
				// 子信息都不符合要求，那么返回自身
			}

			private sealed class DebugView {
				private readonly LinkedExceptionHandlerInfo[] _children;
				private readonly ExceptionHandlerInfo[] _handlers;

				[DebuggerBrowsable(DebuggerBrowsableState.RootHidden)]
				public LinkedExceptionHandlerInfo[] Children => _children;

				public ExceptionHandlerInfo[] Handlers => _handlers;

				public DebugView(LinkedExceptionHandlerInfo linkedExceptionHandlerInfo) {
					if (linkedExceptionHandlerInfo == null)
						throw new ArgumentNullException(nameof(linkedExceptionHandlerInfo));

					if (linkedExceptionHandlerInfo._children != null)
						_children = linkedExceptionHandlerInfo._children.ToArray();
					if (linkedExceptionHandlerInfo._handlers != null)
						_handlers = linkedExceptionHandlerInfo._handlers.ToArray();
				}
			}
		}
	}
}
