using System;
using System.Collections.Generic;

namespace ControlFlow.Blocks {
	/// <summary>
	/// 添加引用
	/// </summary>
	/// <param name="source">发生跳转的块</param>
	/// <param name="target">目标</param>
	/// <param name="scope"><see cref="BlockXref(List{IBlock}, IBlock, AddXrefCallback)"/> 中传入的参数 scope</param>
	public delegate void AddXrefCallback(BasicBlock source, BasicBlock target, IBlock scope);

	/// <summary>
	/// 分析块直接的引用与反向引用关系
	/// </summary>
	public sealed class BlockXref : BlockEnumerator {
		private readonly List<IBlock> _blocks;
		private readonly IBlock _scope;
		private readonly AddXrefCallback _addXref;

		/// <summary>
		/// 构造器
		/// </summary>
		/// <param name="blocks"></param>
		/// <param name="scope"></param>
		/// <param name="addXref"></param>
		public BlockXref(List<IBlock> blocks, IBlock scope, AddXrefCallback addXref) {
			if (blocks == null)
				throw new ArgumentNullException(nameof(blocks));
			if (scope == null)
				throw new ArgumentNullException(nameof(scope));

			_blocks = blocks;
			_scope = scope;
			_addXref = addXref;
		}

		/// <summary>
		/// 分析
		/// </summary>
		public void Analyze() {
			Enumerate(_blocks);
		}

		/// <summary />
		protected override void OnBasicBlock(BasicBlock basicBlock) {
			if (basicBlock.FallThrough != null)
				_addXref(basicBlock, basicBlock.FallThrough, _scope);
			if (basicBlock.ConditionalTarget != null)
				_addXref(basicBlock, basicBlock.ConditionalTarget, _scope);
			if (basicBlock.SwitchTargets != null) {
#if DEBUG
				int oldCount;

				oldCount = basicBlock.SwitchTargets.Count;
#endif
				for (int i = 0; i < basicBlock.SwitchTargets.Count; i++) {
					// 这里不使用foreach，如果用了foreach，AddXrefCallback中将无法更新basicBlock.SwitchTargets
#if DEBUG
					if (basicBlock.SwitchTargets.Count != oldCount)
						// 我们可以更新SwitchTargets中的元素，但是不能进行改变元素总数的操作
						throw new InvalidOperationException();
#endif
					_addXref(basicBlock, basicBlock.SwitchTargets[i], _scope);
				}
			}
		}
	}
}
