using System.Reflection;

[assembly: AssemblyTitle("cflite")]
[assembly: AssemblyProduct("cflite")]
[assembly: AssemblyCopyright("Copyright © 2018 Wwh")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
