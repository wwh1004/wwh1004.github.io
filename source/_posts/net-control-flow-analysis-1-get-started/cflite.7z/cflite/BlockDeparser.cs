using System;
using System.Collections.Generic;
using System.Diagnostics;
using dnlib.DotNet.Emit;

namespace ControlFlow.Blocks {
	/// <summary>
	/// 从块到指令列表的转换器
	/// </summary>
	public sealed class BlockDeparser {
		private readonly MethodBlock _methodBlock;
		private readonly List<BasicBlock> _basicBlocks;
		private List<Instruction> _instructions;
		private List<ExceptionHandler> _exceptionHandlers;
		private List<Local> _variables;
		private bool _isDeparsed;

		/// <summary>
		/// 指令列表
		/// </summary>
		public List<Instruction> Instructions {
			get {
				if (!_isDeparsed)
					throw new InvalidOperationException();

				return _instructions;
			}
		}

		/// <summary>
		/// 异常处理列表
		/// </summary>
		public List<ExceptionHandler> ExceptionHandlers {
			get {
				if (!_isDeparsed)
					throw new InvalidOperationException();

				return _exceptionHandlers;
			}
		}

		/// <summary>
		/// 局部变量列表
		/// </summary>
		public List<Local> Variables {
			get {
				if (!_isDeparsed)
					throw new InvalidOperationException();

				return _variables;
			}
		}

		/// <summary>
		/// 构造器
		/// </summary>
		/// <param name="methodBlock"></param>
		public BlockDeparser(MethodBlock methodBlock) {
			if (methodBlock == null)
				throw new ArgumentNullException(nameof(methodBlock));

			_methodBlock = methodBlock;
			_basicBlocks = new List<BasicBlock>();
		}

		/// <summary>
		/// 转换
		/// </summary>
		public void Deparse() {
			new BlockLayouter(_basicBlocks).LayoutAndCreateBlockInfo(_methodBlock);
			GenerateInstructions();
			GenerateExceptionHandlers();
			GenerateVariables();
			foreach (BasicBlock basicBlock in _basicBlocks)
				basicBlock.PopExtraData();
			_isDeparsed = true;
		}

		private void GenerateInstructions() {
			_instructions = new List<Instruction>();
			for (int i = 0; i < _basicBlocks.Count - 1; i++) {
				BasicBlock basicBlock;

				basicBlock = _basicBlocks[i];
				if (basicBlock.IsEmpty && basicBlock.BranchOpcode.Code == Code.Br && basicBlock.FallThrough == _basicBlocks[i + 1])
					basicBlock.PeekExtraData<BlockInfo>().CanSkip = true;
			}
			// 设置CanSkip
			foreach (BasicBlock basicBlock in _basicBlocks) {
				Instruction branchInstruction;

				branchInstruction = basicBlock.PeekExtraData<BlockInfo>().BranchInstruction;
				branchInstruction.OpCode = basicBlock.BranchOpcode;
				if (branchInstruction.OpCode.FlowControl == FlowControl.Branch)
					branchInstruction.Operand = GetFirstInstruction(basicBlock.FallThrough);
				else if (branchInstruction.OpCode.FlowControl == FlowControl.Cond_Branch)
					if (branchInstruction.OpCode.Code == Code.Switch) {
						Instruction[] switchTargets;

						switchTargets = new Instruction[basicBlock.SwitchTargets.Count];
						for (int i = 0; i < switchTargets.Length; i++)
							switchTargets[i] = GetFirstInstruction(basicBlock.SwitchTargets[i]);
						branchInstruction.Operand = switchTargets;
					}
					else
						branchInstruction.Operand = GetFirstInstruction(basicBlock.ConditionalTarget);
			}
			// 添加跳转指令
			for (int i = 0; i < _basicBlocks.Count; i++) {
				BasicBlock basicBlock;
				BlockInfo blockInfo;
				Instruction branchInstruction;
				BasicBlock nextBasicBlock;

				basicBlock = _basicBlocks[i];
				blockInfo = basicBlock.PeekExtraData<BlockInfo>();
				if (blockInfo.CanSkip)
					continue;
				branchInstruction = blockInfo.BranchInstruction;
				nextBasicBlock = i + 1 == _basicBlocks.Count ? null : _basicBlocks[i + 1];
				if (branchInstruction.OpCode.Code == Code.Br) {
					AppendInstructions(basicBlock, basicBlock.FallThrough == nextBasicBlock);
					// 为无条件跳转指令时，如果直达块就是下一个块，那么可以省略分支指令
				}
				else if (branchInstruction.OpCode.FlowControl == FlowControl.Cond_Branch) {
					AppendInstructions(basicBlock, false);
					if (basicBlock.FallThrough != nextBasicBlock)
						// 需要修复跳转
						_instructions.Add(new Instruction(OpCodes.Br, GetFirstInstruction(basicBlock.FallThrough)));
				}
				else
					AppendInstructions(basicBlock, false);

			}
		}

		private void AppendInstructions(BasicBlock basicBlock, bool canSkipBranchInstruction) {
			if (!basicBlock.IsEmpty)
				_instructions.AddRange(basicBlock.Instructions);
			if (!canSkipBranchInstruction)
				_instructions.Add(basicBlock.PeekExtraData<BlockInfo>().BranchInstruction);
		}

		private void GenerateExceptionHandlers() {
			_exceptionHandlers = new List<ExceptionHandler>();
			for (int i = _basicBlocks.Count - 1; i >= 0; i--) {
				// 最里面的异常块应该首先声明。(错误: 0x801318A4)
				// 所以我们倒序遍历
				BasicBlock basicBlock;
				List<TryBlock> tryBlocks;

				basicBlock = _basicBlocks[i];
				tryBlocks = basicBlock.PeekExtraData<BlockInfo>().TryBlocks;
				if (tryBlocks == null || tryBlocks.Count == 0)
					continue;
				for (int j = tryBlocks.Count - 1; j >= 0; j--) {
					TryBlock tryBlock;

					tryBlock = tryBlocks[j];
					foreach (ScopeBlock scopeBlock in tryBlock.Handlers)
						if (scopeBlock is FilterBlock) {
							FilterBlock filterBlock;

							filterBlock = (FilterBlock)scopeBlock;
							_exceptionHandlers.Add(GetExceptionHandler(tryBlock, GetFirstBasicBlock(filterBlock.FirstBlock), filterBlock.Handler));
						}
						else {
							HandlerBlock handlerBlock;

							handlerBlock = (HandlerBlock)scopeBlock;
							_exceptionHandlers.Add(GetExceptionHandler(tryBlock, null, handlerBlock));
						}
				}
			}
		}

		private ExceptionHandler GetExceptionHandler(TryBlock tryBlock, BasicBlock filterStart, HandlerBlock handlerBlock) {
			BasicBlock tryStart;
			BasicBlock tryEnd;
			int endIndex;
			BasicBlock handlerStart;
			BasicBlock handlerEnd;

			tryStart = GetFirstBasicBlock(tryBlock.FirstBlock);
			tryEnd = GetFirstBasicBlock(tryBlock.LastBlock);
			endIndex = tryEnd.PeekExtraData<BlockInfo>().Index + 1;
			tryEnd = endIndex == _basicBlocks.Count ? null : _basicBlocks[endIndex];
			// dnlib中的end和我们的end不一样，要进行转换
			if (tryEnd == null)
				// 这个情况理论上不可能出现，除非是无效异常处理信息
				throw new InvalidOperationException();
			handlerStart = GetFirstBasicBlock(handlerBlock.FirstBlock);
			handlerEnd = GetFirstBasicBlock(handlerBlock.LastBlock);
			endIndex = handlerEnd.PeekExtraData<BlockInfo>().Index + 1;
			handlerEnd = endIndex == _basicBlocks.Count ? null : _basicBlocks[endIndex];
			// 这里handlerEnd可能为null
			return new ExceptionHandler() {
				TryStart = GetFirstInstruction(tryStart),
				TryEnd = GetFirstInstruction(tryEnd),
				HandlerStart = GetFirstInstruction(handlerStart),
				HandlerEnd = handlerEnd == null ? null : GetFirstInstruction(handlerEnd),
				FilterStart = filterStart == null ? null : GetFirstInstruction(filterStart),
				CatchType = handlerBlock?.CatchType,
				HandlerType = filterStart == null ? GetHandlerType(handlerBlock.Type) : ExceptionHandlerType.Filter
			};
		}

		private static BasicBlock GetFirstBasicBlock(IBlock block) {
			return (BasicBlock)GetFirstBasicBlockImpl(block);
		}

		private static IBlock GetFirstBasicBlockImpl(IBlock block) {
			if (block is BasicBlock)
				return block;
			else
				return GetFirstBasicBlockImpl(((ScopeBlock)block).FirstBlock);
		}

		private Instruction GetFirstInstruction(BasicBlock basicBlock) {
			BlockInfo blockInfo;

			while (true) {
				blockInfo = basicBlock.PeekExtraData<BlockInfo>();
				if (blockInfo.CanSkip)
					basicBlock = _basicBlocks[blockInfo.Index + 1];
				else
					break;
			}
			if (basicBlock.IsEmpty)
				return blockInfo.BranchInstruction;
			else
				return basicBlock.Instructions[0];
		}

		private static ExceptionHandlerType GetHandlerType(ScopeBlockType type) {
			switch (type) {
			case ScopeBlockType.Catch:
				return ExceptionHandlerType.Catch;
			case ScopeBlockType.Finally:
				return ExceptionHandlerType.Finally;
			case ScopeBlockType.Fault:
				return ExceptionHandlerType.Fault;
			default:
				throw new InvalidOperationException();
			}
		}

		private void GenerateVariables() {
			List<Local> oldVariables;
			bool[] variableReferences;

			_variables = new List<Local>();
			oldVariables = _methodBlock.Variables;
			if (oldVariables.Count == 0)
				return;
			variableReferences = new bool[oldVariables.Count];
			foreach (Instruction instruction in _instructions) {
				switch (instruction.OpCode.Code) {
				case Code.Ldloc:
				case Code.Ldloca:
				case Code.Stloc:
					Local variable;

					variable = (Local)instruction.Operand;
					if (variable == null) {
						Debug.Assert(false);
						break;
					}
					variableReferences[oldVariables.IndexOf(variable)] = true;
					break;
				}
			}
			for (int i = 0; i < oldVariables.Count; i++)
				if (variableReferences[i])
					_variables.Add(oldVariables[i]);
		}

		private sealed class BlockInfo {
			private readonly int _index;
			private readonly Instruction _branchInstruction;
			private readonly List<TryBlock> _tryBlocks;
			private bool _canSkip;

			public int Index => _index;

			public Instruction BranchInstruction => _branchInstruction;

			public List<TryBlock> TryBlocks => _tryBlocks;

			/// <summary>
			/// 表示当前块是否可以被跳过（当前块必须为只有一条br指令，br的目标就是下一个基本块）
			/// </summary>
			public bool CanSkip {
				get => _canSkip;
				set => _canSkip = value;
			}

			public BlockInfo(int index, List<TryBlock> tryBlocks) {
				_index = index;
				_branchInstruction = new Instruction();
				if (tryBlocks.Count != 0)
					_tryBlocks = new List<TryBlock>(tryBlocks);
			}
		}

		private sealed class BlockLayouter : BlockEnumerator {
			private readonly List<BasicBlock> _basicBlocks;
			private readonly List<TryBlock> _lastTryBlocks;
			private int _index;

			public BlockLayouter(List<BasicBlock> basicBlocks) {
				if (basicBlocks == null)
					throw new ArgumentNullException(nameof(basicBlocks));

				_basicBlocks = basicBlocks;
				_lastTryBlocks = new List<TryBlock>();
			}

			public void LayoutAndCreateBlockInfo(MethodBlock methodBlock) {
				Enumerate(methodBlock);
			}

			protected override void OnBasicBlock(BasicBlock basicBlock) {
				basicBlock.PushExtraData(new BlockInfo(_index, _lastTryBlocks));
				_basicBlocks.Add(basicBlock);
				_lastTryBlocks.Clear();
				_index++;
			}

			protected override void OnTryBlockEnter(TryBlock tryBlock) {
				_lastTryBlocks.Add(tryBlock);
			}
		}
	}
}
