using System;
using System.Collections.Generic;

namespace ControlFlow.Blocks {
	/// <summary>
	/// 创建递归模型
	/// </summary>
	/// <param name="blocks"></param>
	/// <param name="scope"></param>
	/// <returns></returns>
	public delegate BlockRecursiveModel BlockRecursiveModelCreator(List<IBlock> blocks, IBlock scope);

	/// <summary>
	/// 提供一个模型简化递归代码
	/// </summary>
	public abstract class BlockRecursiveModel {
		/// <summary />
		protected readonly List<IBlock> _blocks;
		/// <summary />
		protected readonly IBlock _scope;

		/// <summary>
		/// 构造器
		/// </summary>
		/// <param name="blocks"></param>
		/// <param name="scope"></param>
		protected BlockRecursiveModel(List<IBlock> blocks, IBlock scope) {
			if (blocks == null)
				throw new ArgumentNullException(nameof(blocks));
			if (scope == null)
				throw new ArgumentNullException(nameof(scope));

			_blocks = blocks;
			_scope = scope;
		}

		/// <summary>
		/// 对当前块列表执行非递归操作，如果操作成功，返回 <see langword="true"/>
		/// </summary>
		/// <returns></returns>
		protected abstract bool Execute();

		/// <summary>
		/// 执行递归操作，如果操作成功，返回 <see langword="true"/>
		/// </summary>
		/// <param name="scopeBlock"></param>
		/// <param name="recursiveModelProvider"></param>
		/// <returns></returns>
		protected static bool Execute(ScopeBlock scopeBlock, BlockRecursiveModelCreator recursiveModelProvider) {
			InternalRecursiveModel internalRecursiveModel;

			internalRecursiveModel = new InternalRecursiveModel(recursiveModelProvider);
			return internalRecursiveModel.Execute(scopeBlock);
		}

		private sealed class InternalRecursiveModel : BlockEnumerator {
			private readonly BlockRecursiveModelCreator _recursiveModelProvider;
			private bool _isModified;

			public InternalRecursiveModel(BlockRecursiveModelCreator recursiveModelProvider) {
				if (recursiveModelProvider == null)
					throw new ArgumentNullException(nameof(recursiveModelProvider));

				_recursiveModelProvider = recursiveModelProvider;
			}

			public bool Execute(ScopeBlock scopeBlock) {
				Enumerate(scopeBlock);
				return _isModified;
			}

			/// <summary>
			/// 使用On***Leave是从最小范围的作用域块开始处理，
			/// 而使用On***Enter是从最大范围的作用域块开始处理，
			/// 几乎所有情况下，从最小范围开始处理是最优的，可以避免很多问题
			/// </summary>
			/// <param name="scopeBlock"></param>
			protected override void OnScopeBlockLeave(ScopeBlock scopeBlock) {
				_isModified |= _recursiveModelProvider(scopeBlock.Blocks, scopeBlock).Execute();
			}
		}
	}
}
