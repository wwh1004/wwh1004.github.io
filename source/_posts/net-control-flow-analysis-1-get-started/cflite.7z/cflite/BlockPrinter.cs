using System;
using System.Text;
using dnlib.DotNet.Emit;

namespace ControlFlow.Blocks {
	/// <summary>
	/// 显示所有块
	/// </summary>
	public sealed class BlockPrinter : BlockEnumerator {
		private readonly IBlock _block;
		private readonly StringBuilder _buffer;
		private int _indent;
		private bool _needNewLine;

		private BlockPrinter(IBlock block) {
			if (block == null)
				throw new ArgumentNullException(nameof(block));

			_block = block;
			_buffer = new StringBuilder();
		}

		/// <summary>
		/// 转换为字符串
		/// </summary>
		/// <param name="block"></param>
		/// <returns></returns>
		public static string ToString(IBlock block) {
			return new BlockPrinter(block).GetString();
		}

		private string GetString() {
			ushort id;
			string result;

			id = 0;
			_block.PushExtraDataAllBasicBlocks(() => id++);
			Enumerate(_block);
			_block.PopExtraDataAllBasicBlocks();
			result = _buffer.ToString(0, _buffer.Length - Environment.NewLine.Length);
			return result;
		}

		/// <summary />
		protected override void OnBasicBlock(BasicBlock basicBlock) {
			StringBuilder branchInfo;

			if (_needNewLine)
				_buffer.AppendLine();
			WriteLine("// " + GetBlockIdString(basicBlock) + (basicBlock.IsEmpty ? " (empty)" : string.Empty));
			for (int i = 0; i < basicBlock.Instructions.Count; i++)
				WriteLine(basicBlock.Instructions[i].ToString());
			branchInfo = new StringBuilder();
			branchInfo.Append("// opcode:" + basicBlock.BranchOpcode.ToString());
			if (basicBlock.BranchOpcode.FlowControl == FlowControl.Branch)
				branchInfo.Append(" | fallthrough:" + GetBlockIdString(basicBlock.FallThrough));
			else if (basicBlock.BranchOpcode.FlowControl == FlowControl.Cond_Branch) {
				branchInfo.Append(" | fallthrough:" + GetBlockIdString(basicBlock.FallThrough));
				if (basicBlock.BranchOpcode.Code == Code.Switch) {
					branchInfo.Append(" | switchtarget:{");
					foreach (BasicBlock target in basicBlock.SwitchTargets)
						branchInfo.Append(GetBlockIdString(target) + " ");
					branchInfo[branchInfo.Length - 1] = '}';
				}
				else
					branchInfo.Append(" | condtarget:" + GetBlockIdString(basicBlock.ConditionalTarget));
			}
			WriteLine(branchInfo.ToString());
			_needNewLine = true;
		}

		/// <summary />
		protected override void OnScopeBlockLeave(ScopeBlock scopeBlock) {
			_indent -= 2;
			WriteLine("}");
			_needNewLine = true;
		}

		/// <summary />
		protected override void OnTryBlockEnter(TryBlock tryBlock) {
			if (_needNewLine)
				_buffer.AppendLine();
			WriteLine(".try");
			WriteLine("{");
			_indent += 2;
			_needNewLine = false;
		}

		/// <summary />
		protected override void OnFilterBlockEnter(FilterBlock filterBlock) {
			WriteLine("filter");
			WriteLine("{");
			_indent += 2;
			_needNewLine = false;
		}

		/// <summary />
		protected override void OnHandlerBlockEnter(HandlerBlock handlerBlock) {
			switch (handlerBlock.Type) {
			case ScopeBlockType.Catch:
				if (handlerBlock.CatchType == null)
					WriteLine("catch");
				else
					WriteLine($"catch {handlerBlock.CatchType.ToString()}");
				break;
			case ScopeBlockType.Finally:
				WriteLine("finally");
				break;
			case ScopeBlockType.Fault:
				WriteLine("fault");
				break;
			default:
				throw new InvalidOperationException();
			}
			WriteLine("{");
			_indent += 2;
			_needNewLine = false;
		}

		/// <summary />
		protected override void OnMethodBlockEnter(MethodBlock methodBlock) {
			WriteLine(".method");
			WriteLine("{");
			_indent += 2;
			_needNewLine = false;
		}

		private string GetBlockIdString(BasicBlock basicBlock) {
			return "BLK_" + basicBlock.PeekExtraData<ushort>().ToString("X4");
		}

		private void WriteLine(string value) {
			_buffer.Append(' ', _indent);
			_buffer.AppendLine(value);
		}
	}
}
