using System;
using System.Collections.Generic;
using System.Reflection;
using ControlFlow.Blocks;
using dnlib.DotNet;

namespace ControlFlow {
	internal static class Program {
		private static void Main(string[] args) {
			using (ModuleDefMD moduleDef = LoadModuleDef(Assembly.GetExecutingAssembly().Location))
				foreach (MethodDef methodDef in moduleDef.EnumerateAllMethodDefs()) {
					if (!methodDef.HasBody)
						continue;
					Console.WriteLine(methodDef.FullName);
					Console.WriteLine(BlockPrinter.ToString(methodDef.CreateMethodBlock()));
					Console.WriteLine();
				}
			Console.ReadKey(true);
		}

		private static ModuleDefMD LoadModuleDef(string filePath) {
			ModuleContext moduleContext;
			ModuleCreationOptions moduleCreationOptions;

			moduleContext = new ModuleContext();
			moduleCreationOptions = new ModuleCreationOptions(moduleContext) {
				TryToLoadPdbFromDisk = false
			};
			return ModuleDefMD.Load(filePath, moduleCreationOptions);
		}

		private static IEnumerable<MethodDef> EnumerateAllMethodDefs(this ModuleDefMD moduleDef) {
			uint methodTableLength;

			methodTableLength = moduleDef.TablesStream.MethodTable.Rows;
			for (uint rid = 1; rid <= methodTableLength; rid++)
				yield return moduleDef.ResolveMethod(rid);
		}
	}
}
