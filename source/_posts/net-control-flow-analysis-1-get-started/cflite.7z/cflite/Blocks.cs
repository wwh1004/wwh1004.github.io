using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using dnlib.DotNet;
using dnlib.DotNet.Emit;

namespace ControlFlow.Blocks {
	/// <summary>
	/// 作用域块类型
	/// </summary>
	public enum ScopeBlockType {
		/// <summary>
		/// 普通的作用域块
		/// </summary>
		Normal,

		/// <summary>
		/// Try块
		/// </summary>
		Try,

		/// <summary>
		/// Filter块
		/// </summary>
		Filter,

		/// <summary>
		/// Catch块
		/// </summary>
		Catch,

		/// <summary>
		/// Finally块
		/// </summary>
		Finally,

		/// <summary>
		/// Fault块（C#语言本身不会用到，但是语法糖yield return生成的代码会出现）
		/// </summary>
		Fault
	}

	/// <summary>
	/// 表示一个块
	/// </summary>
	public interface IBlock {
		/// <summary>
		/// 当前块所属作用域
		/// </summary>
		IBlock Scope { get; set; }

		/// <summary>
		/// 是否有额外数据
		/// </summary>
		bool HasExtraData { get; }

		/// <summary>
		/// 添加一个额外数据
		/// </summary>
		/// <param name="obj"></param>
		void PushExtraData(object obj);

		/// <summary>
		/// 删除一个额外数据
		/// </summary>
		void PopExtraData();

		/// <summary>
		/// 获取最后一个额外数据，但不删除
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <returns></returns>
		T PeekExtraData<T>();
	}

	/// <summary />
	public abstract class BlockBase : IBlock {
		private IBlock _scope;
		private Stack<object> _extraDataStack;

		/// <summary />
		protected BlockBase() {
		}

		/// <summary />
		public IBlock Scope {
			get => _scope;
			set => _scope = value;
		}

		/// <summary />
		public bool HasExtraData => _extraDataStack != null && _extraDataStack.Count != 0;

		/// <summary />
		public T PeekExtraData<T>() {
			return (T)_extraDataStack.Peek();
		}

		/// <summary />
		public void PopExtraData() {
			_extraDataStack.Pop();
		}

		/// <summary />
		public void PushExtraData(object obj) {
			if (_extraDataStack == null)
				_extraDataStack = new Stack<object>();
			_extraDataStack.Push(obj);
		}
	}

	/// <summary>
	/// 基本块
	/// </summary>
	[DebuggerDisplay("{ToDebugString()}")]
	public sealed class BasicBlock : BlockBase {
		private List<Instruction> _instructions;
		private OpCode _branchOpcode;
		private BasicBlock _fallThrough;
		private BasicBlock _conditionalTarget;
		private List<BasicBlock> _switchTargets;

		/// <summary>
		/// 指令
		/// </summary>
		public List<Instruction> Instructions {
			get => _instructions;
			set => _instructions = value;
		}

		/// <summary>
		/// 是否为一个空的块
		/// </summary>
		public bool IsEmpty => _instructions.Count == 0;

		/// <summary>
		/// 分支指令操作码
		/// </summary>
		public OpCode BranchOpcode {
			get => _branchOpcode;
			set => _branchOpcode = value;
		}

		/// <summary>
		/// 直达块
		/// </summary>
		public BasicBlock FallThrough {
			get => _fallThrough;
			set => _fallThrough = value;
		}

		/// <summary>
		/// 当条件成立时跳转到的块
		/// </summary>
		public BasicBlock ConditionalTarget {
			get => _conditionalTarget;
			set => _conditionalTarget = value;
		}

		/// <summary>
		/// Switch指令跳转块
		/// </summary>
		public List<BasicBlock> SwitchTargets {
			get => _switchTargets;
			set => _switchTargets = value;
		}

		/// <summary>
		/// 构造器
		/// </summary>
		/// <param name="instructions"></param>
		public BasicBlock(IEnumerable<Instruction> instructions) {
			if (instructions == null)
				throw new ArgumentNullException(nameof(instructions));

			_instructions = new List<Instruction>(instructions);
		}

		private string ToDebugString() {
			StringBuilder stringBuilder;

			stringBuilder = new StringBuilder();
			if (IsEmpty)
				stringBuilder.Append("empty");
			else {
				stringBuilder.Append("start:IL_");
				stringBuilder.Append(_instructions[0].Offset.ToString("X4"));
			}
			stringBuilder.Append(" ");
			stringBuilder.Append(_branchOpcode.ToString());
			return stringBuilder.ToString();
		}
	}

	/// <summary>
	/// 作用域块
	/// </summary>
	[DebuggerDisplay("L:{Blocks.Count} T:{Type.ToString()}")]
	[DebuggerTypeProxy(typeof(DebugView))]
	public abstract class ScopeBlock : BlockBase {
		/// <summary />
		protected List<IBlock> _blocks;
		/// <summary />
		protected ScopeBlockType _type;

		/// <summary>
		/// 子块
		/// </summary>
		public List<IBlock> Blocks {
			get => _blocks;
			set => _blocks = value;
		}

		/// <summary>
		/// 作用域块的第一个块
		/// </summary>
		public IBlock FirstBlock {
			get => _blocks[0];
			set => _blocks[0] = value;
		}

		/// <summary>
		/// 作用域块的最后一个块
		/// </summary>
		public IBlock LastBlock {
			get => _blocks[_blocks.Count - 1];
			set => _blocks[_blocks.Count - 1] = value;
		}

		/// <summary>
		/// 类型
		/// </summary>
		public ScopeBlockType Type {
			get => _type;
			set => _type = value;
		}

		/// <summary>
		/// 构造器
		/// </summary>
		/// <param name="blocks"></param>
		/// <param name="type"></param>
		protected ScopeBlock(IEnumerable<IBlock> blocks, ScopeBlockType type) {
			if (blocks == null)
				throw new ArgumentNullException(nameof(blocks));

			_blocks = new List<IBlock>(blocks);
			_type = type;
		}

		private sealed class DebugView {
			private readonly IBlock[] _blocks;

			[DebuggerBrowsable(DebuggerBrowsableState.RootHidden)]
			public IBlock[] Blocks => _blocks;

			public DebugView(ScopeBlock scopeBlock) {
				if (scopeBlock == null)
					throw new ArgumentNullException(nameof(scopeBlock));

				_blocks = scopeBlock._blocks.ToArray();
			}
		}
	}

	/// <summary>
	/// Try块
	/// </summary>
	public sealed class TryBlock : ScopeBlock {
		private readonly List<ScopeBlock> _handlers;

		/// <summary>
		/// Filter/Handler列表
		/// </summary>
		public List<ScopeBlock> Handlers => _handlers;

		/// <summary>
		/// 构造器
		/// </summary>
		/// <param name="blocks"></param>
		public TryBlock(IEnumerable<IBlock> blocks) : base(blocks, ScopeBlockType.Try) {
			_handlers = new List<ScopeBlock>();
		}
	}

	/// <summary>
	/// Filter块
	/// </summary>
	public sealed class FilterBlock : ScopeBlock {
		private HandlerBlock _handler;

		/// <summary>
		/// Handler
		/// </summary>
		public HandlerBlock Handler {
			get => _handler;
			set => _handler = value;
		}

		/// <summary>
		/// 构造器
		/// </summary>
		/// <param name="blocks"></param>
		/// <param name="handlerBlock"></param>
		public FilterBlock(IEnumerable<IBlock> blocks, HandlerBlock handlerBlock) : base(blocks, ScopeBlockType.Filter) {
			_handler = handlerBlock;
		}
	}

	/// <summary>
	/// Handler块
	/// </summary>
	public sealed class HandlerBlock : ScopeBlock {
		private ITypeDefOrRef _catchType;

		/// <summary>
		/// 捕获异常类型
		/// </summary>
		public ITypeDefOrRef CatchType {
			get => _catchType;
			set => _catchType = value;
		}

		/// <summary>
		/// 构造器
		/// </summary>
		/// <param name="blocks"></param>
		/// <param name="type"></param>
		/// <param name="catchType"></param>
		public HandlerBlock(IEnumerable<IBlock> blocks, ScopeBlockType type, ITypeDefOrRef catchType) : base(blocks, type) {
			if (!IsValidHandlerBlockType(type))
				throw new ArgumentOutOfRangeException(nameof(type));

			_catchType = catchType;
		}

		private static bool IsValidHandlerBlockType(ScopeBlockType type) {
			switch (type) {
			case ScopeBlockType.Catch:
			case ScopeBlockType.Finally:
			case ScopeBlockType.Fault:
				return true;
			default:
				return false;
			}
		}
	}

	/// <summary>
	/// 表示一个分割成许多 <see cref="IBlock"/> 的方法
	/// </summary>
	public sealed class MethodBlock : ScopeBlock {
		private List<Local> _variables;

		/// <summary>
		/// 局部变量
		/// </summary>
		public List<Local> Variables {
			get => _variables;
			set => _variables = value;
		}

		/// <summary>
		/// 构造器
		/// </summary>
		/// <param name="blocks">子块</param>
		/// <param name="variables">局部变量</param>
		public MethodBlock(IEnumerable<IBlock> blocks, IEnumerable<Local> variables) : base(blocks, ScopeBlockType.Normal) {
			if (variables == null)
				throw new ArgumentNullException(nameof(variables));

			_variables = new List<Local>(variables);
		}
	}
}
