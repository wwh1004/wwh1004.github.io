using System;
using System.Collections.Generic;

namespace ControlFlow.Blocks {
	/// <summary>
	/// 块排序器（有“副作用”，会清除未引用的块）
	/// </summary>
	public sealed class BlockSorter : BlockRecursiveModel {
		private BlockSorter(List<IBlock> blocks, IBlock scope) : base(blocks, scope) {
		}

		/// <summary>
		/// 为作用域块中所有块采用递归进行全部排序
		/// </summary>
		/// <param name="scopeBlock"></param>
		/// <returns></returns>
		public static bool Sort(ScopeBlock scopeBlock) {
			return Execute(scopeBlock, (blocks, scope) => new BlockSorter(blocks, scope));
		}

		/// <summary />
		protected override bool Execute() {
			int i;

			switch (_blocks.Count) {
			case 0:
			case 1:
				return false;
			}
			foreach (IBlock block in _blocks)
				block.PushExtraData(new BlockInfo());
			new BlockXref(_blocks, _scope, AddXref).Analyze();
			i = 0;
			foreach (IBlock block in new TopologicalSorter(_blocks).Sort()) {
				_blocks[i] = block;
				i++;
			}
			if (i != _blocks.Count)
				// 可能在排序前执行了一些操作，导致_blocks中存在未引用的块，排序之后我们要清除这些块
				_blocks.RemoveRange(i, _blocks.Count - i);
			foreach (IBlock block in _blocks)
				block.PopExtraData();
			return true;
			// 也许块列表被更新了，也许没被更新，这个不好判断，判断起来损失性能太大
			// 几乎所有情况下都会造成块列表的更新（比如顺序变化，有未引用的块被清除），所以我们直接返回true
		}

		private static void AddXref(BasicBlock source, BasicBlock target, IBlock scope) {
			IBlock targetRoot;
			List<IBlock> references;

			targetRoot = target.GetRootBlock(scope);
			if (targetRoot == null)
				// 跳出scope范围的我们不做处理
				return;
			references = source.GetRootBlock(scope).PeekExtraData<BlockInfo>().References;
			if (!references.Contains(targetRoot))
				references.Add(targetRoot);
		}

		private sealed class BlockInfo {
			private readonly List<IBlock> _references;
			private bool _isVisited;

			public List<IBlock> References => _references;

			public bool IsVisited {
				get => _isVisited;
				set => _isVisited = value;
			}

			public BlockInfo() {
				_references = new List<IBlock>();
			}
		}

		private sealed class TopologicalSorter {
			private readonly List<IBlock> _blocks;
			private readonly Stack<IBlock> _blockStack;

			public TopologicalSorter(List<IBlock> blocks) {
				if (blocks == null)
					throw new ArgumentNullException(nameof(blocks));

				_blocks = blocks;
				_blockStack = new Stack<IBlock>(_blocks.Count);
			}

			public Stack<IBlock> Sort() {
				DfsSort(_blocks[0]);
				return _blockStack;
			}

			private void DfsSort(IBlock block) {
				BlockInfo blockInfo;

				blockInfo = block.PeekExtraData<BlockInfo>();
				blockInfo.IsVisited = true;
				for (int i = blockInfo.References.Count - 1; i >= 0; i--)
					if (!blockInfo.References[i].PeekExtraData<BlockInfo>().IsVisited)
						DfsSort(blockInfo.References[i]);
				_blockStack.Push(block);
			}
		}
	}
}
