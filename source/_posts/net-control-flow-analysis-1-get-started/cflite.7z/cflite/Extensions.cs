using System;
using System.Collections.Generic;
using dnlib.DotNet;
using dnlib.DotNet.Emit;

namespace ControlFlow.Blocks {
	/// <summary>
	/// 扩展类
	/// </summary>
	public static class Extensions {
		/// <summary>
		/// 创建对应的 <see cref="MethodBlock"/>
		/// </summary>
		/// <param name="methodDef"></param>
		/// <returns></returns>
		public static MethodBlock CreateMethodBlock(this MethodDef methodDef) {
			if (methodDef == null)
				throw new ArgumentNullException(nameof(methodDef));

			BlockParser parser;

			methodDef.SimplifyMacros();
			parser = new BlockParser(methodDef.Body.Instructions, methodDef.Body.ExceptionHandlers, methodDef.Body.Variables);
			parser.Parse(true);
			return parser.MethodBlock;
		}

		/// <summary>
		/// 化简指令
		/// </summary>
		/// <param name="methodDef"></param>
		public static void SimplifyMacros(this MethodDef methodDef) {
			if (methodDef == null)
				throw new ArgumentNullException(nameof(methodDef));

			methodDef.Body.SimplifyMacros(methodDef.Parameters);
		}

		/// <summary>
		/// 从 <see cref="MethodBlock"/> 还原 <see cref="MethodDef"/>
		/// </summary>
		/// <param name="methodDef"></param>
		/// <param name="methodBlock"></param>
		public static void Restore(this MethodDef methodDef, MethodBlock methodBlock) {
			if (methodDef == null)
				throw new ArgumentNullException(nameof(methodDef));
			if (methodBlock == null)
				throw new ArgumentNullException(nameof(methodBlock));

			BlockDeparser deparser;

			deparser = new BlockDeparser(methodBlock);
			deparser.Deparse();
			methodDef.Restore(deparser);
		}

		/// <summary>
		/// 从 <see cref="MethodBlock"/> 还原 <see cref="CilBody"/>
		/// </summary>
		/// <param name="body"></param>
		/// <param name="methodBlock"></param>
		public static void Restore(this CilBody body, MethodBlock methodBlock) {
			if (body == null)
				throw new ArgumentNullException(nameof(body));
			if (methodBlock == null)
				throw new ArgumentNullException(nameof(methodBlock));

			BlockDeparser deparser;

			deparser = new BlockDeparser(methodBlock);
			deparser.Deparse();
			body.Restore(deparser);
		}

		/// <summary>
		/// 从 <see cref="BlockDeparser"/> 还原 <see cref="MethodDef"/>
		/// </summary>
		/// <param name="methodDef"></param>
		/// <param name="deparser"></param>
		public static void Restore(this MethodDef methodDef, BlockDeparser deparser) {
			if (methodDef == null)
				throw new ArgumentNullException(nameof(methodDef));

			Restore(methodDef.Body, deparser);
		}

		/// <summary>
		/// 从 <see cref="BlockDeparser"/> 还原 <see cref="CilBody"/>
		/// </summary>
		/// <param name="body"></param>
		/// <param name="deparser"></param>
		public static void Restore(this CilBody body, BlockDeparser deparser) {
			if (body == null)
				throw new ArgumentNullException(nameof(body));
			if (deparser == null)
				throw new ArgumentNullException(nameof(deparser));

			ReplaceList(deparser.Instructions, body.Instructions);
			ReplaceList(deparser.ExceptionHandlers, body.ExceptionHandlers);
			ReplaceList(deparser.Variables, body.Variables);
		}

		private static void ReplaceList<T>(List<T> source, IList<T> destination) {
			List<T> destination2;

			destination.Clear();
			destination2 = destination as List<T>;
			if (destination2 == null)
				foreach (T item in source)
					destination.Add(item);
			else
				destination2.AddRange(source);
		}

		/// <summary>
		/// 获取一个包含 block 的块，并且这个块的所属作用域为 scope 。如果不存在，返回 <see langword="null"/> 。
		/// </summary>
		/// <param name="block"></param>
		/// <param name="scope"></param>
		/// <returns></returns>
		public static IBlock GetRootBlock(this IBlock block, IBlock scope) {
			if (block == null)
				throw new ArgumentNullException(nameof(block));
			if (scope == null)
				throw new ArgumentNullException(nameof(scope));

			while (true) {
				if (block.Scope == scope)
					return block;
				else
					block = block.Scope;
				if (block == null)
					return null;
			}
		}

		/// <summary>
		/// 为所有基本块添加一个额外数据
		/// </summary>
		/// <param name="block"></param>
		/// <param name="extraDataCreator"></param>
		public static void PushExtraDataAllBasicBlocks(this IBlock block, Func<object> extraDataCreator) {
			if (block == null)
				throw new ArgumentNullException(nameof(block));
			if (extraDataCreator == null)
				throw new ArgumentNullException(nameof(extraDataCreator));

			new ExtraDataHelper(block, extraDataCreator).Execute();
		}

		/// <summary>
		/// 为所有基本块删除最后一个额外数据
		/// </summary>
		/// <param name="block"></param>
		public static void PopExtraDataAllBasicBlocks(this IBlock block) {
			if (block == null)
				throw new ArgumentNullException(nameof(block));

			new ExtraDataHelper(block, null).Execute();
		}

		private sealed class ExtraDataHelper : BlockEnumerator {
			private readonly IBlock _block;
			private readonly Func<object> _extraDataCreator;

			/// <summary>
			/// 构造器
			/// </summary>
			/// <param name="block"></param>
			/// <param name="extraDataCreator">参数为 <see langword="null"/> 表示为添加模式，反之为删除模式</param>
			public ExtraDataHelper(IBlock block, Func<object> extraDataCreator) {
				if (block == null)
					throw new ArgumentNullException(nameof(block));

				_block = block;
				_extraDataCreator = extraDataCreator;
			}

			public void Execute() {
				Enumerate(_block);
			}

			protected override void OnBasicBlock(BasicBlock basicBlock) {
				if (_extraDataCreator == null)
					basicBlock.PopExtraData();
				else
					basicBlock.PushExtraData(_extraDataCreator());
			}
		}
	}
}
